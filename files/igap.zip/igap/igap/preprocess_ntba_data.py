from igap import common
import numpy as np
from scipy.interpolate import interp1d
import os
import json
import logging
from glob import glob


class DataPreprocessor(object):
    _logger = logging.getLogger("ntBA_preprocess")

    @classmethod
    def _process_data(cls, potentials_ntba_array, output_folder=None, shift_step=500,
                      name_tag="", is_histon_data=False):
        region_id, region_position, ntba_data, chemical_list, strand = cls._read_all_potentials(
            potentials_ntba_array,
            is_histon_data)
        unique_ids, unique_gene_strands = cls._get_unique_genes(region_id, strand)

        new_x, sum_all_genes_dba, all_data, all_gene_ids, mean_all_genes_dba = cls._interpolate_data(
            ntba_data,
            region_id,
            region_position,
            unique_ids,
            chemical_list,
            unique_gene_strands,
            shift_step)
        output_files = {}
        if output_folder is not None:
            output_files['sum'] = os.path.join(output_folder,
                                               name_tag.replace(" ", "_") + "_output.tsv")
            common.write_tsv_with_names(sum_all_genes_dba, "Position ", chemical_list, new_x,
                                        output_files['sum'])
            output_files['mean'] = os.path.join(output_folder,
                                                name_tag.replace(" ", "_") + "_output_mean.tsv")
            common.write_tsv_with_names(mean_all_genes_dba, "Position ", chemical_list, new_x,
                                        output_files['mean'])
            if all_data is not None:
                output_files['all'] = os.path.join(
                    output_folder, name_tag.replace(" ", "_") + "_output_all_data.tsv")
                common.write_tsv_with_names(all_data, "Position ", all_gene_ids, new_x, output_files['all'])
        cls._logger.info("Processing the nTBA files has been finished successfully")
        return output_files

    @classmethod
    def _merge_bed_file_and_results(cls, previous_computation_array_for_chemicals, ref_bed_file, tag_name,
                                    output_folder, is_mix=False,min_overlap=0.001):
        out_files = []
        orig_file_name = []
        cls._logger.info("Creating merge bed files for " + tag_name)
        if is_mix:
            file_list = []
            chr_list = []
            for item in previous_computation_array_for_chemicals:
                file_list += glob(item)
            for item in file_list:
                with open(item) as fi:
                    chr_list.append(fi.readline().split('\t')[0])
        else:
            file_list = previous_computation_array_for_chemicals
        for i, res in enumerate(file_list):
            out_file = os.path.join(output_folder, res.split(".")[0].split("/")[-1] + tag_name + ".bed")
            if is_mix:
                orig_file_name.append(out_file)
                out_file = os.path.join(output_folder,
                                        res.split(".")[0].split("/")[-1] + tag_name + '_chr' + chr_list[i] + ".bed")

            os.system("bedtools intersect -a " + ref_bed_file + " -b " + res + " -wa -wb -f "+str(min_overlap)+" >  " + out_file)
            out_files.append(out_file)
        if is_mix:
            tmp_out_files = []
            for i in range(len(previous_computation_array_for_chemicals)):
                size_file = int(len(out_files) / len(previous_computation_array_for_chemicals))
                os.system('cat ' + (' ').join(out_files[i * size_file:(i + 1) * size_file]) + ' > ' + orig_file_name[
                    i * size_file])
                tmp_out_files.append(orig_file_name[i * size_file])
            out_files = tmp_out_files
        return out_files

    @classmethod
    def _read_tsv_dba(cls, tsv_file, seps="\t"):
        with open(tsv_file) as f:
            row_ids = []
            array = []
            for line in f:
                lines = line.split(seps)
                tmp_id = ":".join(lines[0:4]) + '|' + lines[4]
                tmp_str = lines[-2].split('|')
                tmp_id2 = (tmp_id, tmp_str[1], tmp_str[2], tmp_str[3], str(int(tmp_str[4]) + 25 - int(lines[1])))
                tmp_id3 = "|".join(tmp_id2)
                row_ids.append(tmp_id3)
                array.append(lines[-1].replace("\n", ""))
        return array, row_ids

    @classmethod
    def _read_all_potentials(cls, potentials_ntba_array, is_hot_code):
        cls._logger.info("Start to reading the bed file")
        if not isinstance(potentials_ntba_array, list):
            potentials_ntba_array = [potentials_ntba_array]

        ntba_data_for_chemicals = []
        chemical_list = []
        for input_file in potentials_ntba_array:
            chemical_list.append(input_file.split("/")[-1].split("_")[1])
            if is_hot_code:
                mean_dba_data, gene_col, gene_ids = common.read_tsv_with_names(input_file)
                chemical_list = gene_col
                ntba_data_for_chemicals = mean_dba_data
                continue
            else:
                mean_dba_data, gene_ids = cls._read_tsv_dba(input_file)
            ntba_data_for_chemicals.append(mean_dba_data)

        genes_id = []
        genes_position = []
        strand_lst = []
        for gene in gene_ids:
            splited_name = gene.split('|')
            name = splited_name[0] + "|" + splited_name[1]
            strand = ''
            for st in splited_name:
                if ';+' in st:
                    strand = '+'
                    break
                elif ';-' in st:
                    strand = '-'
                    break
            if strand != '':
                strand_lst.append(strand)
            else:
                raise ValueError('No strand found for ' + gene)
            gene_pos = splited_name[-1]
            genes_id.append(name.lower())
            genes_position.append(gene_pos)

        return np.asarray(genes_id), np.asarray(genes_position, int), ntba_data_for_chemicals, chemical_list, strand_lst

    @classmethod
    def _get_unique_genes(cls, region_id, strand):
        cls._logger.info("Start to extracting unique regions...")
        unique_ids, unique_indexes = np.unique(region_id, True)
        cls._logger.info("Total number of lines equals to " + str(len(region_id)))
        cls._logger.info("Total number of unique ones equals to " + str(len(unique_ids)))

        return unique_ids, np.asarray(strand)[unique_indexes].tolist()

    @classmethod
    def preprocess_ntba_data(cls, config_file, output_folder,min_overlap=0.001):
        with open(config_file) as json_file:
            configs = json.load(json_file)
        ntba_files = configs['ntba_bed_files_address']
        files = {}
        for index, task in enumerate(configs['region_files']):
            chromosome = configs['chromosome']
            is_mix = chromosome.lower() == 'mix'
            if chromosome.lower() != 'mix':
                bed_f = common.filter_bed_files_based_on_chr(task['bed_file_address'], chromosome)
            else:
                bed_f = task['bed_file_address']
            bed_file_address = cls._merge_bed_file_and_results(ntba_files, bed_f,
                                                               task["name"].replace(" ", ""),
                                                               output_folder, is_mix,min_overlap)

            files[task['name']] = cls._process_data(potentials_ntba_array=bed_file_address,
                                                    output_folder=output_folder, name_tag=task["name"])
        return files

    @classmethod
    def _interpolate_data(cls, dba_data, all_genes, genes_pos, unique_genes, chemical_list, unique_gene_strands,
                          shift_step):
        cls._logger.info("start to Interpolating for missed point")
        shift_step = int(shift_step)
        list_of_all_genes_id = []
        list_of_all_genes_dba_point_value = []
        sum_potential_dba = []
        mean_potential_dba = []
        max_len = shift_step * 2
        new_x = np.linspace(0, max_len, num=int(max_len / 5) + 1, endpoint=True)
        for pot_index, potential in enumerate(chemical_list):
            sum_all_genes_dba = None
            for gene_index, gene in enumerate(unique_genes):
                list_of_all_genes_id.append(gene + ':' + potential)

                indexes = np.where(all_genes == gene)[0]
                x_value = genes_pos[indexes]
                y_value = np.asarray(dba_data[pot_index], float)[indexes]
                sorted_index = np.argsort(x_value)
                x_value = np.insert(x_value[sorted_index], 0, 0)

                if unique_gene_strands[gene_index] == '-':
                    y_value = np.insert(y_value[sorted_index][::-1], 0, 0)
                else:
                    y_value = np.insert(y_value[sorted_index], 0, 0)

                data_generator = interp1d(x_value, y_value, bounds_error=False, fill_value=0)
                new_x = np.linspace(0, max_len, num=int(max_len / 5) + 1, endpoint=True)
                new_y = data_generator(new_x)

                if sum_all_genes_dba is None:
                    sum_all_genes_dba = new_y
                else:
                    sum_all_genes_dba = np.array(sum_all_genes_dba) + new_y

                list_of_all_genes_dba_point_value.append(new_y)

            mean_potential_dba.append(np.array(sum_all_genes_dba, float) / len(unique_genes))
            sum_potential_dba.append(np.array(sum_all_genes_dba, float))
        return np.asarray(new_x - shift_step,
                          int), sum_potential_dba, list_of_all_genes_dba_point_value, list_of_all_genes_id, mean_potential_dba
