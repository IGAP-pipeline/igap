import glob
import os
import numpy as np
import sys
import logging
from igap import parallel, common
import shutil
import stat


class BayesPi_nTBA(object):
    _logger = logging.getLogger("BayesPi_nTBA")

    @classmethod
    def calculate_ntba(cls, chemical_potentials, reference_sequences, iterations, pwm_folder, output_folder,
                       reuse_output,
                       parallel_dict, use_interct=False, random_seed=False, only_collect=False, remove_temp=True,
                       only_merge=False, input_folder="", window_size=50):
        try:
            files = glob.glob(
                os.path.join(("/").join(os.path.abspath(__file__).split('/')[0:-1]), "bin", "*", "bayesPI_affinity"))
            for file in files:
                st = os.stat(file)
                os.chmod(file, st.st_mode | stat.S_IEXEC)

            if only_merge is False:
                parallel_dict = parallel.get_parallel_dict(parallel_dict)
                cls._run_bayespibar_ntba_oneseq(output_folder, reference_sequences, chemical_potentials,
                                                reuse_output,
                                                only_collect, parallel_dict, pwm_folder, iterations,
                                                random_seed,
                                                use_interct, remove_temp)
            else:
                cls._convert_dba_to_bed_file(input_folder, window_size)
                cls._merge_bed_file(input_folder, output_folder, chemical_potentials, remove_temp)
        except RuntimeError:
            cls._logger.exception("Runtime error happened")
            exit(1)

    @classmethod
    def _run_bayespibar_ntba_oneseq(cls, output_folder, reference_sequences, chemical_potentials, reuse_output,
                                    only_collect, parallel_dict, pwm_folder, iterations, random_seed, use_interct,
                                    remove_temp):

        try:
            ref_seqs = common.read_fasta(reference_sequences)

            ref_names, dups = common.uniq_and_duplicates(name for name, _ in ref_seqs)
            if len(dups) != 0:
                raise IOError(
                    "Duplicate sequence names in " + reference_sequences + ": " + ", ".join(dups))

            if only_collect is False:
                runner = parallel.Parallel(parallel_dict['use_slurm'], parallel_dict['use_cores'],
                                           parallel_dict['slurm_account'], parallel_dict['max_nodes'],
                                           parallel_dict['max_memory'], os.path.join(output_folder, "parallel_tmp"))
                commands = []
                commands.extend(
                    cls._calculate_dba(ref_seqs, pwm_folder, output_folder, iterations,
                                       chemical_potentials, random_seed, reuse_output, use_interct,
                                       fasta_file=reference_sequences))

                runner.run_commands(commands, "dba")
                if remove_temp is True and os.path.isdir(os.path.join(output_folder, "parallel_tmp")):
                    shutil.rmtree(os.path.join(output_folder, "parallel_tmp"))
            else:
                cls._logger.info("Skip calculation ... ")

            cls._logger.info("Collecting dbA values...")
            cls._collect_mean_dba(output_folder, remove_temp)
        except IOError as err:
            raise RuntimeError("Error computing dbA: " + str(err))

    @classmethod
    def _calculate_dba(cls, seqs, pwm_folder, res_folder, iterations, chemical_potentials, seed, reuse_output,
                       use_interct, fasta_file):
        res_folder = os.path.abspath(res_folder)
        if len(seqs) == 0:
            raise IOError("No sequences found in source seq")

        seq_names = [s[0] for s in seqs]
        seq_names_set = frozenset(seq_names)
        if len(seq_names) != len(seq_names_set):
            raise IOError("Duplicate sequence names in source_ref: " +
                          ", ".join(set([x for x in seq_names if seq_names.count(x) > 1])))

        num_sequences = len(seqs)
        pwm_files = common.get_pwms(pwm_folder)
        cls._logger.info("Calculating dbA values for " + str(num_sequences) + " sequences in source ref and " + str(
            len(pwm_files)) + " PWMs in " + pwm_folder + " using " + str(
            iterations) + " background iterations and " + str(
            len(chemical_potentials)) + " chemical potential(s): " + ", ".join(chemical_potentials))

        commands = []
        for potential in chemical_potentials:
            potential_result_folder = os.path.join(res_folder, "potential_" + potential)
            if not os.path.exists(potential_result_folder):
                os.mkdir(potential_result_folder)

            for pwm in pwm_files:
                if reuse_output:
                    output_file = os.path.join(potential_result_folder, os.path.basename(pwm) +
                                               "_bindingP_0_randomBackground_" + str(iterations))

                    if os.path.exists(output_file):
                        try:
                            dba_data = common.read_tsv(output_file, skip=1)
                            file_seq_names = frozenset(dba_data[0])
                            modified_seq_names = frozenset([x.split("||")[1] for x in seq_names_set])
                            if file_seq_names == modified_seq_names:
                                continue  # the data in the file seems ok, do not schedule the recalculation
                        except Exception:
                            pass

                if use_interct:
                    interct_file = pwm.replace(".mlp", ".interct")
                    if not os.path.exists(interct_file):
                        interct_file = None
                else:
                    interct_file = None
                if seed is False:
                    seed = 0
                else:
                    seed = 1
                commands.append(cls._generate_compute_affinity_command(fasta_file, pwm, iterations,
                                                                       potential_result_folder, potential,
                                                                       seed,
                                                                       interct_file))

        return commands

    @classmethod
    def _generate_compute_affinity_command(cls, fasta_file, pwm_file, background_iterations, output_folder, potential,
                                           seed,
                                           interct_file):

        bin_folder = os.path.abspath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "igap", "bin"))

        platform_subfolders = {"darwin": "mac", "linux": "linux"}

        platform = sys.platform
        bin_subfolder = None
        for platform_name, subfolder in platform_subfolders.items():
            if platform.startswith(platform_name):
                bin_subfolder = os.path.join(bin_folder, subfolder)
                break

        if bin_subfolder is None:
            cls._logger.error(
                "Unknown platform:" + platform + ". This package has binary components for the following platforms:" +
                ", ".join(platform_subfolders.keys()))
            exit(1)

        bayespi_affinity = os.path.join(bin_subfolder, "bayesPI_affinity")

        return bayespi_affinity + " -potential=" + ("0" if potential == "none" else "1") + (
            " -override_potential=" + str(potential) if common.is_number(
                potential) else "") + " -strand=2 -psam=" + common.quote(pwm_file) + " -seq=" + common.quote(
            fasta_file) + " -shuffle=" + str(background_iterations) + " -seed=" + str(seed) + " -out=" + common.quote(
            output_folder) + " -is_ntba=1" + ((" -di_nucfile=" + interct_file) if interct_file is not None else "")

    @classmethod
    def _collect_mean_dba(cls, dba_folder, remove_temp):
        potentials = glob.glob(os.path.join(dba_folder, "potential_*"))

        if len(potentials) == 0:
            raise IOError("No usable dbA data found in folder " + dba_folder)

        pwms_found = None
        for potential_folder in potentials:
            pwm_dba_files = glob.glob(os.path.join(potential_folder, "*_bindingP_0_randomBackground_*"))
            if len(pwm_dba_files) == 0:
                raise IOError("No usable dbA data found in folder " + potential_folder)

            base_pwms = frozenset(map(os.path.basename, pwm_dba_files))
            if pwms_found is None:
                pwms_found = base_pwms
            elif pwms_found != base_pwms:
                raise IOError("Different PWM results found in " + potential_folder)

            dbas = []
            mean_dbas = []
            col_names = []
            loop = 1
            is_ids = True
            seps = "\t"
            seqs = None
            needs_to_be_removed = []
            for pwm in pwm_dba_files:
                pwm_data, pwm_header, pwm_row_ids = common.read_tsv_dba(pwm, seps, is_ids)

                # only read once and assume all files have same row ids
                if is_ids:
                    seqs = pwm_row_ids

                # plus is faster than append changed 3 to 2 after using JBW read_tsv_data
                if loop == 1:
                    dbas = np.array(pwm_data[0], float)
                    loop += 1
                    is_ids = False
                else:
                    dbas += np.array(pwm_data[0], float)
                if remove_temp is True:
                    if os.path.isfile(os.path.abspath(pwm)):
                        needs_to_be_removed.append(os.path.abspath(pwm))

            heads, tails = os.path.split(potential_folder)
            col_names.append(tails + "|mean_dbA|" + str(len(pwm_dba_files)))
            mean_dbas.append(list(dbas / len(pwm_dba_files)))
            tsv_file_path = os.path.join(dba_folder, "all_dbas_mean_nosort_" + tails.replace('potential_', '') + ".tsv")
            common.write_tsv_with_names(mean_dbas, "Sequence_name", col_names, seqs, tsv_file_path)
            for file in needs_to_be_removed:
                os.remove(file)

    @classmethod
    def _convert_dba_to_bed_file(cls, inputs_folder, window_size):
        if not os.path.exists(inputs_folder):
            raise IOError("Input folder do not exists")

        seps = "\t"
        shift_pos = int(window_size / int(2))

        all_files = os.path.join(inputs_folder, "*", "*.tsv")
        dba_files = sorted(glob.glob(all_files))
        for file in dba_files:
            out_file_path = file.replace(".tsv", ".bed")
            with open(out_file_path, "w") as out_file:
                with open(file) as read_file:
                    for line in read_file:
                        lines = line.split(seps)
                        tmp_name = lines[0]
                        tmp_score = lines[1]
                        if tmp_name == 'Sequence_name':
                            continue
                        tmps = tmp_name.split("|")
                        chrs = tmps[0].lower()
                        out_line = (
                            chrs.replace("chr", ""), str(int(tmps[4]) - shift_pos), str(int(tmps[4]) + shift_pos),
                            tmp_name, tmp_score)
                        out_file.write("\t".join(out_line))

    @classmethod
    def _merge_bed_file(cls, input_folder, output_folder, chemical_potentials, remove_temp):
        cls._logger.info("Merging all the files together ")
        for chemical in chemical_potentials:
            command = "sort  " + os.path.join(input_folder, "*",
                                              "all_dbas_mean_nosort_" + chemical + ".bed") + " -k1,1 -k2,2n -o " + os.path.join(
                output_folder, "chemical_" + chemical + '_combined_groups_dbas_sorted.bed')
            os.system(command)

            if remove_temp is True:
                all_files = os.path.join(input_folder, "*", "all_dbas_mean_nosort_" + chemical + ".bed")
                bed_files = glob.glob(all_files)
                for bed_file in bed_files:
                    os.remove(os.path.abspath(bed_file))

        if remove_temp is True:
            [shutil.rmtree(x) for x in glob.glob(os.path.join(input_folder, '*', "parallel_tmp"))]
