import json
import os
from igap import common
import numpy as np
from scipy import stats
import logging


class Frequency(object):
    _logger = logging.getLogger("Frequency")

    @classmethod
    def calculate_frequency(cls, config_file_address, output_folder='outputs'):
        with open(config_file_address) as json_file:
            json_file = json.load(json_file)
            commands = json_file['config']
            win_length = json_file['win_length']
            potentials = json_file['potentials']
            chromosome = str(json_file['chromosome'])
            cells = json_file['cell_type_config']
        window_length_files = []
        output_files = []
        for win_len in win_length:
            window_length_files.append(os.path.join(output_folder, "windowed_file_for_" + win_len + ".bed"))
            common.create_chr_len_bed_file(int(win_len) * 1000, chromosome,
                                           window_length_files[-1])
        for command in commands:
            bed_file = common.filter_bed_files_based_on_chr(command['bed_file'], chromosome)
            for index, win_len in enumerate(win_length):
                out_combined_file = os.path.join(output_folder,
                                                 bed_file.split('/')[-1].split('.')[0] + 'hic_' + str(win_len) + '.bed')
                os.system("bedtools intersect -a " + bed_file + " -b " + window_length_files[index] +
                          " -wa -wb -f 0.001 >  " + out_combined_file)
                out_files = cls._find_dbas_for_hic_regions(out_combined_file, command['chr_file'],
                                                                 window_length_files[index],
                                                                 potentials, False, output_folder,
                                                                 command['name'],
                                                                 win_len)
                for cell_index, cell in enumerate(command["cells"]):
                    histon_modifications = [hist + cell["name"] for hist in json_file["histon_modification"]]
                    files = cls._find_histon_for_hic_regions(out_combined_file, cell['interp_file'],
                                                                   window_length_files[index],
                                                                   histon_modifications, output_folder,
                                                                   command['name'],
                                                                   win_len)
                    region_val = cls._get_inter_chr_interaction_value_from_txt_file(cells[cell['name']][win_len])
                    for file in out_files + files:
                        out_file = cls._calculate_t_Value(file, region_val,
                                                                output_file=os.path.join(output_folder,
                                                                                         file.split("/")[-1].split(
                                                                                             ".")[0] +
                                                                                         "_final_plot_out.csv"))
                        output_files.append(out_file)
        return output_files

    @classmethod
    def _calculate_t_Value(cls, tsv_file, region_value, random_gen=100, output_file=None):
        data, column, row_x = common.read_tsv_with_names(tsv_file)
        data = np.asarray(data, float)
        tmp_mat = np.zeros(shape=region_value.shape)
        size_of_regions = region_value.shape[0]
        last_percent = -1
        cls._logger.info("Starting to calculate chromosome chromosome tsv files for " + tsv_file)
        for i in range(size_of_regions):
            for j in range(i, size_of_regions):
                if int(((i * size_of_regions + j) / float(size_of_regions * size_of_regions)) * 10) > last_percent:
                    last_percent += 1
                    cls._logger.info(str(last_percent * 10) + " percent completed")
                if region_value[i, j] > 0:
                    sum_ij = data[i, :] + data[j, :]
                    randi = np.random.randint(0, size_of_regions, random_gen)
                    randj = np.random.randint(0, size_of_regions, random_gen)
                    sum_rnd = data[randi, :] + data[randj, :]
                    rand_value_mean = sum_rnd.mean(axis=0)
                    tmp_mat[i, j], _ = stats.ranksums(sum_ij, rand_value_mean)  # mean 201

        if output_file is not None:
            common.write_tsv_with_names(tmp_mat.tolist(), "tvalue_out", column, column, output_file)
        cls._logger.info("finished successfully")
        return output_file

    @classmethod
    def _find_histon_for_hic_regions(cls, bed_file, interp_file, window_file, histon_modifications, output="", name="",
                                     win_size=""):
        file = cls._find_dbas_for_hic_regions(bed_file, interp_file, window_file, histon_modifications,
                                                    True, output, name, win_size, "hic_")
        return file

    @classmethod
    def _multiple_columns_bed_file_to_id(cls, in_file, seps="\t"):
        id = []
        gene_to_id = []
        strand_to_id = []
        with open(in_file) as in_f:
            for line in in_f:
                lines = line.split(seps)
                id.append(":".join((lines[5], lines[6], lines[7], lines[8])).rstrip('\n\r'))
                tmp_genes = lines[3].split("|")
                if len(tmp_genes) > 1:
                    tmp_genes = (tmp_genes[0], tmp_genes[1])
                    tmp_genes = "|".join(tmp_genes)
                else:
                    tmp_genes = tmp_genes[0]
                tmp_gene2id = (lines[0], lines[1], lines[2], tmp_genes.lower())
                tmp_gene2id = ":".join(tmp_gene2id)
                gene_to_id.append(tmp_gene2id)
                strand_to_id.append(lines[4])
        return id, gene_to_id, strand_to_id

    @classmethod
    def _get_inter_chr_interaction_value_from_txt_file(cls, file):
        return np.loadtxt(file)

    @classmethod
    def _find_dbas_for_hic_regions(cls, bed_file, interp_file, window_file, potentials, return_mean=False, output="",
                                   name="", win_size="", file_prefix="nTBA_"):
        data, col_name, x_axis = common.read_tsv_with_names(interp_file, None, None)
        out_files = []
        x_axis = np.array(x_axis, int)
        ID = []
        with open(window_file) as in_f:
            for line in in_f:
                lines = line.split('\t')
                tmp = ":".join(lines)
                tmp = tmp.rstrip("\n\r")
                ID.append(tmp)
        file_id, file_gen_to_id, file_strands_to_id = cls._multiple_columns_bed_file_to_id(bed_file)
        for potential in potentials:
            out_file = os.path.join(output, file_prefix + name + "_" + win_size + "_" + potential + ".tsv")
            record_calculated_data = []
            record_calculated_id = []
            total_data = np.zeros(x_axis.shape[0])
            for HIC_region in ID:
                index = [i for i, x in enumerate(file_id) if x == HIC_region]
                calculated_data = []
                loop = 1
                for i in index:
                    tmp_gene = file_gen_to_id[i] + ":" + potential
                    if tmp_gene in set(col_name):
                        data_index = col_name.index(tmp_gene)
                        if loop == 1:
                            calculated_data = np.array(data[data_index], float)
                        else:
                            calculated_data += np.array(data[data_index], float)
                        loop += 1
                        total_data += np.array(data[data_index], float)
                    else:
                        cls._logger.info("not find" + tmp_gene)
                record_calculated_id.append(HIC_region + ":" + potential + ";" + str(len(index)))
                if len(index) > 0 and len(calculated_data) > 0:
                    if return_mean:
                        record_calculated_data.append(list(calculated_data / float(loop - 1)))
                    else:
                        record_calculated_data.append(calculated_data.tolist())
                else:
                    record_calculated_data.append(np.zeros(x_axis.shape[0]).tolist())
            common.write_tsv_with_names(record_calculated_data,
                                        "Position|" + str(len(record_calculated_data)),
                                        record_calculated_id, x_axis, out_file)
            out_files.append(out_file)

        return out_files
