from igap import common
import numpy as np
from sklearn import preprocessing
import logging
import os


class FeaturesManager:
    _logger = logging.getLogger("FeaturesManager")

    @classmethod
    def process_features(cls, files_list, output_folder, tag_name=""):
        cls._logger.info('Starting to processing features')
        data, normalized = cls._prepare_data_for_freq_plot(files_list)
        np.savetxt(os.path.join(output_folder, 'data_' + tag_name + '.txt'), data)
        np.savetxt(os.path.join(output_folder, 'normalized_' + tag_name + '.txt'), normalized)
        cls._logger.info('Processing the features has been finished successfully')
        return os.path.join(output_folder, 'data_' + tag_name + '.txt'), os.path.join(output_folder,
                                                                                      'normalized_' + tag_name + '.txt')

    @classmethod
    def _prepare_data_for_freq_plot(cls, files):
        processed_data = []
        for file in files:
            data, row, column = common.read_tsv_with_names(file)
            data_index = np.transpose(np.asarray(data, float))
            data_index = np.sum(np.asarray(data_index >= 3, float), 1) / data_index.shape[0]
            processed_data.append(data_index)

        processed_data = np.transpose(np.asarray(processed_data, float) * 100 + 2.22045e-16)
        log_normalized = np.log(processed_data - np.min(processed_data) + 1)
        normalized = preprocessing.scale(log_normalized)

        return processed_data, normalized
