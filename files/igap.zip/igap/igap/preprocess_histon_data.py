import os
import json
from igap import common
import logging
from igap.preprocess_ntba_data import DataPreprocessor



class HistDataPreprocess(object):
    _logger = logging.getLogger("GM_preprocess")

    @classmethod
    def _preprocess_experiment_data(cls, name, file_address, head_file, output_file, chromosome_number, seps="\t"):

        with open(head_file) as header_file:
            column_title = header_file.read().strip().split(seps)
        selected_column = [s for s in column_title if name in s]
        selected_column_index = [column_title.index(s) + 1 for s in column_title if name in s]
        with open(output_file, 'w') as out:
            with open(file_address, 'r') as f:
                for line in f:
                    line = line.split(seps)
                    if str(line[0]) != str(chromosome_number):
                        continue
                    line[-1] = line[-1].rstrip()
                    out_line = seps.join(line[0:4] + [line[i].rstrip("\n\r") for i in selected_column_index])
                    out.write(out_line + "\n")
        return selected_column

    @classmethod
    def _convert_hic_to_new_format(cls, input_file, seps="\t"):
        out_file = input_file.replace(".bed", "_4histonData.bed")
        with open(out_file, "w") as out_f:
            with open(input_file) as in_f:
                for line in in_f:
                    lines = line.split(seps)
                    tmp_col = lines[5] + ":" + lines[6] + ":" + lines[7] + ":" + lines[8]
                    out_line = (lines[0], lines[1], lines[2], lines[3], lines[4], tmp_col)
                    out_line = seps.join(out_line)
                    out_f.write(out_line)
        return out_f.name

    @classmethod
    def _read_and_export_histone_data(cls, tsv_file, out_header, out_file, seps="\t"):
        row_ids = []
        array = []
        with open(out_file, "w") as out_f:
            out_line = seps.join(out_header)
            out_line = "ID" + "\t" + out_line + "\n"
            out_line = out_line.replace("_rep1", "")
            out_line = out_line.replace("_rep2", "")
            out_line = out_line.replace("_Tag", "")
            out_f.write(out_line)
            with open(tsv_file) as f:
                for line in f:
                    lines = line.split(seps)
                    strs = ":"
                    tmp_id = strs.join(lines[0:4])
                    strs2 = "|"
                    tmp_id2 = (tmp_id, lines[3], lines[4], str(int(lines[7]) - int(lines[1])))
                    tmp_id3 = strs2.join(tmp_id2)
                    out_line = [tmp_id3] + lines[9:18]
                    out_line = seps.join(out_line)
                    out_f.write(out_line)
                    row_ids.append(tmp_id3)
                    array.append(lines[9:18])
        return array, row_ids

    @classmethod
    def _read_and_export_histone_data_for_hic(cls, tsv_file, out_header, out_file, seps="\t"):
        row_ids = []
        array = []
        with open(out_file, "w") as out_f:
            out_line = seps.join(out_header)
            out_line = "ID" + "\t" + out_line + "\n"
            out_line = out_line.replace("_rep1", "")
            out_line = out_line.replace("_rep2", "")
            out_line = out_line.replace("_Tag", "")
            out_f.write(out_line)
            with open(tsv_file) as f:
                for line in f:
                    lines = line.split(seps)
                    strs = ":"
                    tmp_id = strs.join(lines[0:4])
                    strs2 = "|"
                    tmp_id2 = (tmp_id, lines[5], lines[4], str(int(lines[8]) - int(lines[1])))
                    tmp_id3 = strs2.join(tmp_id2)
                    out_line = [tmp_id3] + lines[10:19]
                    out_line = seps.join(out_line)
                    out_f.write(out_line)
                    row_ids.append(tmp_id3)
                    array.append(lines[10:19])
        return array, row_ids

    @classmethod
    def _process_data(cls, tss_array, hot_array, output_folder, chr_number, win_len='1000'):
        out_files = {'TSS': {}, 'HOT': {}}
        for obj in tss_array:
            if str(win_len) not in obj["name"]:
                continue
            name_tag = "tss_" + obj["name"]
            out_files['TSS'][name_tag] = DataPreprocessor._process_data(obj["bed"], output_folder,
                                                                        is_histon_data=True,
                                                                        name_tag=name_tag)

        for obj in hot_array:
            name_tag = "hot_chr_" + str(chr_number) + "_" + obj["name"]
            out_files['HOT'][name_tag] = DataPreprocessor._process_data(obj["bed"], output_folder,
                                                                        is_histon_data=True,
                                                                        name_tag=name_tag)
        return out_files

    @classmethod
    def process_histon_data(cls, config_file, output_folder="outputs"):
        plt_tss_dict_array = []
        plt_hot_array = []
        with open(config_file) as json_file:
            configs = json.load(json_file)['config']
        chromosome_number = configs['chromosome']
        bed_file_path = common.filter_bed_files_based_on_chr(configs['hot_region_bed_file'], chromosome_number)

        mat_file_array = []
        hic_config = configs["tss"]
        tss_file_path = common.filter_bed_files_based_on_chr(hic_config["tss_bed_file"], chromosome_number)
        merge_files = [bed_file_path, tss_file_path]
        hic4_files = []
        hic4_files_len = []
        for win_length in configs["tss"]["window_len"]:
            cls._logger.info("generating prerequired files for " + win_length)
            length_bed_out_file = os.path.join(output_folder, str(win_length) + "bp_len_output_chr" + str(
                chromosome_number) + ".bed")
            common.create_chr_len_bed_file(int(win_length) * 1000, chromosome_number, length_bed_out_file)
            for file in merge_files:
                out_combined_file = os.path.join(output_folder, str(win_length) + "_made_now_" + file.split("/")[-1])
                os.system("bedtools intersect -a " + file + " -b " + length_bed_out_file +
                          " -wa -wb -f 0.001 >  " + out_combined_file)
                if file == tss_file_path:
                    hic4_files.append(cls._convert_hic_to_new_format(out_combined_file))
                    hic4_files_len.append(str(win_length))
                mat_file_array.append(out_combined_file)

        for task in configs['hot']["tasks"]:
            cls._logger.info("processing data in " + task['root_folder'])
            input_file = os.path.join(task['root_folder'], task['bed_file_name'])
            header_file = os.path.join(task['root_folder'], task['header_file'])
            output_file = os.path.join(task['root_folder'], "chr_" + str(chromosome_number) + "_data.bed")
            header = cls._preprocess_experiment_data(task['name'], input_file, header_file, output_file,
                                                                    chromosome_number)
            out_combined_file = output_file.replace(".bed", "") + "_any_hot_histon.bed"
            os.system("bedtools intersect -a " + bed_file_path + " -b " + output_file +
                      " -wa -wb -f 0.001 >  " + out_combined_file)
            output_file_final = os.path.join(output_folder,
                                             'chr' + str(chromosome_number) + "_" + task['name'] + ".bed")
            cls._read_and_export_histone_data(out_combined_file, header, output_file_final)
            plt_hot_array.append(
                {"bed": output_file_final, 'name': task['name'] + "_plot"})

            for index, file in enumerate(hic4_files):
                out_combined_file = output_file.replace(".bed", "") + hic4_files_len[index] + ".bed"
                os.system("bedtools intersect -a " + file + " -b " + output_file +
                          " -wa -wb -f 0.001 >  " + out_combined_file)
                out_file = os.path.join(output_folder,
                                        out_combined_file.split("/")[-1].replace(".bed", "") + "_" + task[
                                            "name"] + "_final.bed")
                cls._read_and_export_histone_data_for_hic(out_combined_file, header, out_file)

                plt_tss_dict_array.append({"bed": out_file,
                                           'name': out_combined_file.split("/")[-1].replace(".bed", "") + "_" + task[
                                               "name"] + "_plot"})
        return cls._process_data(plt_tss_dict_array, plt_hot_array, output_folder, chromosome_number,
                                                configs["tss"]["window_len"][0])
