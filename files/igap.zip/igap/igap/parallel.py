import sys
import time
import subprocess
import os
import argparse
import logging
from igap import common


def get_parallel_dict(file_address):
    p_dict = {}
    last_key = None
    with open(file_address, 'r') as po:
        for line in po.readlines():
            line = line.strip()
            if last_key == None:
                last_key = line.replace("-", "")
                if last_key == 'use_slurm':
                    p_dict['use_slurm'] = "True"
                    last_key = None
            else:
                p_dict[last_key] = line
                last_key = None
    p_dict['use_cores'] = int(p_dict['use_cores'])
    p_dict['max_nodes'] = int(p_dict['max_nodes'])
    p_dict['use_slurm'] = common.str2bool(p_dict.get("use_slurm", "False"))
    p_dict['slurm_account'] = p_dict.get("slurm_account", "")
    p_dict['max_memory'] = int(p_dict.get('max_memory', 5800))
    return p_dict


def add_parallel_options(parser):
    parallel_options = parser.add_argument_group('parallelization arguments')

    parallel_options.add_argument("--use_cores", help="number of cores to use on one machine",
                                  type=int, default=4, metavar="NUMBER")

    parallel_options.add_argument("--use_slurm", help="use SLURM workload manager to distribute computations across "
                                                      "nodes",
                                  action="store_true")

    parallel_options.add_argument("--slurm_account", help="SLURM account name", type=str, metavar="NAME")

    parallel_options.add_argument("--max_nodes", help="maximum number of nodes to allocate when using SLURM",
                                  type=int, default=8, metavar="NUMBER")

    parallel_options.add_argument("--max_memory", help="maximum Memory for the process",
                                  type=int, default=5800, metavar="NUMBER")


def slurm_present():
    return common.which("sbatch") is not None


def single_node_parallel(commands, tmp_folder, num_processes, name):
    if len(commands) == 0:
        return

    logging.info("Running %d jobs in %d parallel processes" % (len(commands), min(int(num_processes), len(commands))))
    common.clear_folder(tmp_folder)

    processes = []
    commands_processed = 0
    while len(commands) > 0:
        while len(processes) >= int(num_processes):
            for i in range(len(processes)):
                if processes[i].poll() is not None:
                    del processes[i]
                    break

            if len(processes) >= int(num_processes):
                time.sleep(0.01)

        with open(os.path.join(tmp_folder, name + "_" + str(commands_processed) + ".out"), "wb") as out:
            with open(os.path.join(tmp_folder, name + "_" + str(commands_processed) + ".err"), "wb") as err_file:
                processes.append(subprocess.Popen(commands[0], shell=True, stdout=out, stderr=err_file))

        commands_processed += 1
        del commands[0]

    for p in processes:
        p.wait()


def make_sbatch_header(job_name, account_name, max_time_hours, memory_mbytes, num_cpus, num_nodes=1):
    out_seq = "#!/bin/bash\n"
    out_seq += "#SBATCH --job-name=" + job_name + "\n"
    if account_name is not None:
        out_seq += "#SBATCH --account=" + account_name + "\n"
    out_seq += "#SBATCH --time=" + str(max_time_hours) + ":00:00\n"
    out_seq += "#SBATCH --mem-per-cpu=" + str(memory_mbytes) + "\n"
    out_seq += "#SBATCH --cpus-per-task=" + str(num_cpus) + "\n"
    out_seq += "#SBATCH --nodes=" + str(num_nodes) + "\n"
    return out_seq


def slurm_parallel(commands, tmp_folder, name, num_processes, max_nodes, account, max_memory):
    if len(commands) == 0:
        return

    use_nodes = max_nodes
    if use_nodes > (len(commands) - 1) / num_processes + 1:
        use_nodes = (len(commands) - 1) / num_processes + 1

    logging.info("Splitting %d jobs into %d nodes (up to %d processes each using Slurm)" % (
        len(commands), use_nodes, num_processes))

    common.clear_folder(tmp_folder)
    use_nodes = int(use_nodes)
    node_commands = [[] for _ in range(use_nodes)]
    while len(commands) > 0:
        for n in range(use_nodes):
            node_commands[n].append(commands[0])
            del commands[0]
            if len(commands) == 0:
                break

    done_files = []
    for n in range(use_nodes):
        node_tag = name + "_node_" + str(n)
        commands_file = os.path.abspath(os.path.join(tmp_folder, "commands_for_" + node_tag))
        common.write_lines(node_commands[n], commands_file)

        job_file = os.path.abspath(os.path.join(tmp_folder, "job_" + node_tag))
        with open(job_file, "w") as f:
            f.write(make_sbatch_header(name.replace(".", "") + str(n), account,
                                       14, max_memory, min(num_processes, len(node_commands[n]))))
            f.write("\n")
            f.write("python3 " + os.path.abspath(__file__) + " --use_cores " + str(num_processes) +
                    " --commands_file " + commands_file +
                    " --tmp_folder " + os.path.abspath(os.path.join(tmp_folder, "out_" + node_tag)) +
                    " --name " + name + "\n")

            done_file = os.path.abspath(os.path.join(tmp_folder, node_tag + "_done"))
            f.write("echo done > " + done_file + "\n")
            done_files.append(done_file)

        os.system("sbatch -o " + common.quote(os.path.abspath(os.path.join(tmp_folder, node_tag + "_slurm-%j.out"))) +
                  " " + common.quote(job_file))

    logging.info("Waiting for jobs to finish...")

    while True:
        missing = False
        for df in done_files:
            if not os.path.exists(df):
                missing = True
                break

        if not missing:
            break

        time.sleep(5)


class Parallel:
    def __init__(self, use_slurm, use_cores, slurm_account, max_nodes, max_memory, tmp_folder):
        self.cores = use_cores
        if use_slurm:
            if not slurm_present():
                raise IOError("SLURM workload manager not detected")

            self.slurm = True
        else:
            self.slurm = False

        self.slurm_account = slurm_account
        self.slurm_max_nodes = max_nodes
        self.tmp_folder = tmp_folder
        self.max_memory = max_memory

    def run_commands(self, commands, name):
        if self.slurm:
            slurm_parallel(commands, self.tmp_folder, name, self.cores, self.slurm_max_nodes, self.slurm_account,
                           self.max_memory)
        else:
            single_node_parallel(commands, self.tmp_folder, self.cores, name)


if __name__ == "__main__":
    _logger = logging.getLogger("Parallel")
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter,
                                     description="""This program runs commands from """
                                                 """the given file in parallel.""", add_help=False)
    try:
        required_named = parser.add_argument_group('required arguments')
        optional = parser.add_argument_group('optional arguments')

        required_named.add_argument("--commands_file", help="file name with commands to run, one command per line",
                                    required=True, metavar="FILE")

        optional.add_argument("--tmp_folder", help="folder to put the temporary files (will be erased)", type=str,
                              metavar="FOLDER", default="result")

        optional.add_argument("--name", help="name tag for jobs", type=str,
                              metavar="FOLDER", default="job")

        optional.add_argument("-h", "--help", action="help", help="show this help message and exit")

        add_parallel_options(parser)

        args = parser.parse_args()
    except IOError as err:
        _logger.info("Command line arguments error:%s" % err, file=sys.stderr)
        exit(1)

    try:
        runner = Parallel(args.use_slurm, args.use_cores, args.slurm_account, args.max_nodes, args.max_memory,
                          args.tmp_folder)
        commands = common.read_lines(args.commands_file)
        runner.run_commands(commands, args.name)
    except IOError as err:
        _logger.info("Error running commands:%s" % err, file=sys.stderr)
        exit(1)
