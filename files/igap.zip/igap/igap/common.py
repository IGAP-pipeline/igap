import csv
import os
import glob
import shutil
import math


def transpose_list(l):
    return zip(*l)


def clear_folder(folder):
    if os.path.exists(folder):
        shutil.rmtree(folder)
    os.makedirs(folder)


def create_chr_len_bed_file(window_len, chromosome, output_file=None, seps="\t", prefix='chr'):
    chr_len = {"1": 249250621, "2": 243199373, "3": 198022430, "4": 191154276, "5": 180915260, "6": 171115067,
               "7": 159138663, "8": 146364022, "9": 141213431, "10": 135534747, "11": 135006516, "12": 133851895,
               "13": 115169878, "14": 107349540, "15": 102531392, "16": 90354753, "17": 81195210, "18": 78077248,
               "19": 59128983, "20": 63025520, "21": 48129895, "22": 51304566, "x": 155270560, "y": 59373566,
               "m": 16571}
    if str(chromosome).lower() not in chr_len:
        raise Exception("Can not find the chromosome length")
    length = chr_len[str(chromosome).lower()]
    out_array = []

    for i in range(0, math.ceil(length / window_len)):
        start_point = 1 + window_len * i
        end_point = min(window_len * (i + 1), length)
        line_out = seps.join(
            [str(chromosome).lower(), str(start_point), str(end_point), prefix + str(chromosome) + "|" + str(i + 1)])
        out_array.append(line_out)
    if output_file != None:
        with open(output_file, 'w') as f:
            for line_out in out_array:
                f.write(line_out + "\n")
    return out_array


def uniq_and_duplicates(a):
    seen = set()
    dups = set()
    for x in a:
        if x not in seen:
            seen.add(x)
        else:
            dups.add(x)

    return seen, dups


def is_exe(fpath):
    return os.path.isfile(fpath) and os.access(fpath, os.X_OK)


def write_lines(lines, file_name):
    with open(file_name, "w") as f:
        f.writelines([str(l) + "\n" for l in lines])


def read_lines(file):
    if isinstance(file, str):
        with open(file) as f:
            return [l.replace("\n", "") for l in f.readlines()]
    else:
        return [l.replace("\n", "") for l in file.readlines()]


def quote(string):
    return "\"" + string + "\""


def which(program):
    fpath, fname = os.path.split(program)
    if fpath:
        if is_exe(program):
            return program
    else:
        for path in os.environ["PATH"].split(os.pathsep):
            path = path.strip('"')
            exe_file = os.path.join(path, program)
            if is_exe(exe_file):
                return exe_file

    return None


def str2bool(v):
    return v.lower() in ("yes", "true", "t", "1")


def read_fasta(fasta_file_name, max_seqs=None):
    sequences = []
    data = ""
    seq_name = None
    with open(fasta_file_name) as ff:
        for line in ff:
            line = line.replace("\n", "")
            if len(line) == 0:
                continue

            if line[0] == '>':
                if data != "":
                    sequences.append((seq_name, data))
                    data = ""
                    if max_seqs is not None and len(sequences) >= max_seqs:
                        break

                seq_name = line[1:]
            else:
                data += line.strip()

    if data != "":
        sequences.append((seq_name, data))

    return sequences


def get_pwms(pwm_folder):
    if not os.path.exists(pwm_folder):
        raise IOError("PWM folder, " + pwm_folder + " does not exist")

    pwm_files = glob.glob(os.path.join(pwm_folder, "*.mlp"))
    if len(pwm_files) == 0:
        raise IOError("No .mlp files found in the PWM folder " + pwm_folder)

    return pwm_files


def read_tsv(tsv_file, skip=0, sep="\t", return_header=False, skip_comments=False):
    header = None
    if not isinstance(tsv_file, str):
        data = list(csv.reader(tsv_file, delimiter=sep))
    else:
        with open(tsv_file) as f:
            data = list(csv.reader(f, delimiter=sep))

    if skip_comments:
        data = [row for row in data if row[0][0] != "#"]

    if return_header:
        header = data[0]
        if skip == 0:
            skip = 1

    data = data[skip:]

    if len(data) == 0:
        return []

    num_cols = len(data[0])
    cols = [None] * num_cols
    for c in range(num_cols):
        cols[c] = [row[c] for row in data]

    if return_header:
        return cols, header

    return cols


def get_chromosome_index(chromosome):
    if str(chromosome).lower() == 'x':
        return 23
    return int(chromosome)


def write_tsv(rows, tsv_file, prefix=None):
    with open(tsv_file, "w") as f:
        if prefix is not None:
            f.write(prefix + "\n")

        for r in rows:
            f.write("\t".join(map(str, r)) + "\n")


def filter_bed_files_based_on_chr(bed_file, chromosome, seps="\t"):
    out_file = bed_file.split(".")[0] + "_" + str(chromosome) + ".bed"
    with open(out_file, 'w') as f:
        with open(bed_file) as in_f:
            for line in in_f:
                splited_line = line.split(seps)
                if splited_line[0] == str(get_chromosome_index(chromosome)):
                    splited_line[0] = chromosome
                    f.write(seps.join(splited_line))
    return out_file


def filter_tag_files_based_on_chr(tag_file, chromosome):
    out_file = tag_file.split(".")[0] + "_" + str(chromosome) + ".tag"
    with open(out_file, 'w') as f:
        with open(tag_file) as in_f:
            for line in in_f:
                if line.split(':')[0] == str(chromosome):
                    f.write(line)
    return out_file


def filter_bed_and_tag_files_based_on_chr(bed_file, tag_file, chromosome, seps="\t"):
    bed_out = filter_bed_files_based_on_chr(bed_file, chromosome, seps)
    tag_out = filter_tag_files_based_on_chr(tag_file, chromosome)
    return bed_out, tag_out


def read_tsv_dba(tsv_file, seps="\t", is_ids=True):
    col_array = []
    with open(tsv_file) as f:
        header = [x for x in next(f).split(seps)]
        array = []
        row_ids = []
        for line in f:
            lines = line.split(seps)
            if is_ids:
                row_ids.append(lines[0] + '|' + header[1].split(":")[1] + lines[1])
            array.append(lines[2])
    header[0] = header[0].split(":")[0]
    col_array.append(array)
    f.close()
    return col_array, header, row_ids


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


def write_tsv_with_names(data_columns, id_name, col_names, row_names, file_name):
    if len(data_columns) != len(col_names):
        raise IOError("Wrong column names")

    header = [id_name] + col_names
    data_rows = [header] + list(transpose_list([row_names] + data_columns))
    write_tsv(data_rows, file_name)


def get_color_for_plot(count_of_color=-1):
    if count_of_color == 5:
        return ['rgb(255, 0, 0)', 'rgb(0, 255, 0)', 'rgb(0, 0, 255)', 'rgb(0, 255, 255)', 'rgb(255,255,0)']
    elif count_of_color == 4:
        return ['rgb(255, 0, 0)', 'rgb(0, 255, 0)', 'rgb(0, 0, 255)', 'rgb(255,255,0)']
    else:
        return ['rgb(255, 153, 51)', 'rgb(0, 0, 255)', 'rgb(204, 0, 102)', 'rgb(128, 0, 0)', 'rgb(0, 25, 51)',
                'rgb(153, 76, 0)', 'rgb(0,255,0)', 'rgb(0,255,255)', 'rgb(255,0,255)']


def read_tsv_with_names(tsv_file, expected_col_names=None, expected_row_names=None):
    data, header = read_tsv(tsv_file, return_header=True)
    col_names = header[1:]
    if expected_col_names is not None and expected_col_names != col_names:
        raise IOError("Column names in " + tsv_file + " are not as expected")

    row_names = data[0]
    if expected_row_names is not None and expected_row_names != row_names:
        raise IOError("Row names in " + tsv_file + " are not as expected")

    data = data[1:]
    return data, col_names, row_names
