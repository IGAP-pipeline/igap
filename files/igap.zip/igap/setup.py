from setuptools import setup
import os, sys, site

from setuptools.command.install import install as _install
import glob


def binaries_directory():
    if '--user' in sys.argv:
        paths = (site.getusersitepackages(),)
    else:
        py_version = '%s.%s' % (sys.version_info[0], sys.version_info[1])
        paths = (s % (py_version) for s in (
            sys.prefix + '/lib/python%s/dist-packages/',
            sys.prefix + '/lib/python%s/site-packages/',
            sys.prefix + '/local/lib/python%s/dist-packages/',
            sys.prefix + '/local/lib/python%s/site-packages/',
            '/Library/Python/%s/site-packages/',
        ))

    for path in paths:
        if os.path.exists(path):
            break

    executable = glob.glob(os.path.join(path, "*igap*", "igap", "bin", "*", "bayesPI_affinity"))
    for execue in executable:
        print('chmod +x ' + execue)
        os.system('chmod +x ' + execue)


def readme():
    with open('README.rst') as f:
        return f.read()


class install(_install):
    def run(self):
        """Call superclass run method, then downloads the binaries"""
        _install.run(self)
        binaries_directory()


setup(name='igap',
      cmdclass={'install': install},
      version='0.1',
      description='this pipeline designed to compute the ntba value or combine different data for biological application',
      url='https://github.com/alisahaf70/igap',
      author='Alireza Sahaf Naeini',
      author_email='alisahaf70@gmail.com',
      include_package_data=True,
      license='MIT',
      packages=['igap'],
      install_requires=[
          'numpy',
          'scipy',
          'scikit-learn',
      ],
      scripts=['igap/igap'])
