import os
from igap.features_manager import FeaturesManager
import numpy as np
import sys
from plotly import tools
import plotly.graph_objs as go
import plotly
from sklearn import preprocessing
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
import logging
from scipy.spatial.distance import euclidean
from datetime import datetime


def setup_logger(log_folder='logs'):
    if not os.path.exists(log_folder):
        os.makedirs(log_folder)
    log_file = os.path.join(log_folder, datetime.now().strftime('log_%H_%M_%S_%f_%d_%m_%Y.log'))
    logging.basicConfig(filename=log_file, level=logging.INFO, format="%(asctime)s: %(message)s")
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))


def get_sort_value(file_val):
    priority_list = ['nTBA', 'dnas', 'pol', 'h3k4me3', 'h3k27ac', 'h3k4me1', 'h3k27me3', 'h3k9me3', 'ctcf']
    for index, val in enumerate(priority_list):
        if val in file_val:
            return index
    return len(priority_list) + 1


def custom_sort(x):
    # Sort the files for better plotting
    if 'TSS' in x:
        return 0
    elif 'HOT' in x:
        return 1
    else:
        return 2


def apply_threshhold_and_sort_data(interaction_data):
    gtz_elements = np.sum(np.asarray(interaction_data > 0, int), 1)
    gtz_elements = gtz_elements / gtz_elements.shape[0]

    gtz_elements = np.asarray(gtz_elements)
    sorted_index = np.argsort(gtz_elements, kind='stable')
    sorted_elements = gtz_elements[sorted_index]
    return sorted_elements, sorted_index


def sort_cluster_labels_based_on_max(data, label_prob, n_cluster=3):
    out_data = []
    label = np.argmax(label_prob, axis=1)
    for i in range(0, n_cluster):
        indexes = np.where(label == i)
        cluster_item = data[indexes].tolist()
        out_data.append(cluster_item)

    indexes = np.argsort([np.mean(i) for i in out_data])
    new_label_array = []
    for i in label_prob:
        inner_label_array = []
        for new_label, prev_label in enumerate(indexes):
            inner_label_array.append(i[prev_label])
        new_label_array.append(inner_label_array)
    return np.asarray(new_label_array)


def cluster_datas(data, additional_features=None, n_clusters=3):
    additional_features = preprocessing.normalize(
        additional_features.reshape(-1, additional_features.shape[0])).squeeze().reshape(
        additional_features.shape[0], 1)
    kmeans_data = KMeans(n_clusters=n_clusters, random_state=1000, tol=1e-10, n_init=1000).fit(data)

    prob = []
    for i in data:
        inner_prob = []
        for j in kmeans_data.cluster_centers_:
            inner_prob.append(1 / euclidean(i, j))
        prob.append(np.asarray(inner_prob, float) / (np.sum(inner_prob)))
    prob = sort_cluster_labels_based_on_max(data, np.asarray(prob))

    prob2 = GaussianMixture(n_components=3).fit(additional_features).predict_proba(
        additional_features)
    prob2 = sort_cluster_labels_based_on_max(additional_features, prob2)
    prob = 0.75 * prob + 0.25 * prob2
    return np.argmax(prob, axis=1)


def get_csv_files(folder, cell_type, win_len):
    files = os.listdir(folder)
    file_list = []
    label = []

    files = sorted(files, key=lambda x: get_sort_value(x))
    for file in files:
        if (cell_type in file or 'nTBA' in file) and '.csv' in file and win_len in file:
            file_list.append(os.path.join(folder, file))
    file_list = sorted(file_list, key=custom_sort)
    for file in file_list:
        splited_name = file.split('/')[-1].split('.')[0].split('_')
        label.append(splited_name[3] + ' ' + splited_name[1])
    return file_list, label


def draw_box_plot(sorted_elements, label, n_cluster, show_legend):
    data = []
    label = np.asarray(label)
    color_key = ['rgb(255, 0, 0)', 'rgb(0, 255, 0)', 'rgb(0, 0, 255)', 'rgb(0, 255, 255)', 'rgb(255,255,0)']
    name = ['Type I', 'Type II', 'Type III', 'Different cluster in each region']
    for i in [n_cluster] + list(range(n_cluster)):
        indexes = np.argwhere(label == i).squeeze()
        trace = go.Box(y=sorted_elements[indexes], legendgroup='i' + str(i), showlegend=show_legend, name=name[i],
                       fillcolor=color_key[i], line=dict(color=color_key[i + 1]))

        data.append(trace)

    return data


def draw_freq_plot(clustered_data, length, x_axis_labels, title, ref_axis_number=1, show_legend=False,
                   min_val=0, max_val=40):
    color_scale = [[0, 'rgb(255,255,255)'], [1, 'rgb(0,0,0)']]

    clustered_data = np.clip(clustered_data, min_val, max_val)
    trace = go.Heatmap(z=clustered_data, colorscale=color_scale, showscale=show_legend, colorbar=dict(len=0.5))
    data = [trace]
    lines = []
    prev_point = 0
    for i in range(len(length) - 1):
        prev_point += length[i]
        lines.append(
            {
                'type': 'line',
                'x0': -0.5,
                'y0': prev_point,
                'x1': clustered_data.shape[1] - 0.5,
                'y1': prev_point,
                'yref': 'y' + str(ref_axis_number),
                'xref': 'x' + str(ref_axis_number),
                'line': {
                    'color': 'rgb(255, 0, 0)',
                    'width': 3,
                    'dash': 'dashdot',
                },
            },
        )
    layout = go.Layout(shapes=lines, xaxis=go.layout.XAxis(ticktext=x_axis_labels,
                                                           tickvals=list(range(0, clustered_data.shape[1])),
                                                           tickfont=dict(size=9)), title=title, showlegend=False,
                       legend=dict(x=-0.1, y=1))
    fig = {
        'data': data,
        'layout': layout,
    }
    return fig


def draw_scatter_plot(sorted_elements, label, n_cluster, show_legend):
    data = []
    label = np.asarray(label)
    color_key = ['rgb(255, 0, 0)', 'rgb(0, 255, 0)', 'rgb(0, 0, 255)', 'rgb(255,255,0)']
    name = ['Type I', 'Type II', 'Type III', 'Different cluster in each region']
    for i in [n_cluster] + list(range(n_cluster)):
        indexes = np.argwhere(label == i).squeeze()
        trace = go.Scatter(x=indexes, y=sorted_elements[indexes], mode='markers',
                           marker=dict(color=color_key[i], size=3), legendgroup='i' + str(i),
                           showlegend=show_legend,
                           name=name[i])
        data.append(trace)

    return data


def draw_plots(plots, title_prefix, output_folder):
    title = title_prefix + [""] * (len(plots) - len(title_prefix))
    fig_frame = tools.make_subplots(rows=int(len(plots) * len(plots[list(plots.keys())[0]]) / len(title_prefix)),
                                    cols=len(title_prefix),
                                    subplot_titles=title)

    x_axis = [x for x in fig_frame['layout'] if "xaxis" in x]
    y_axis = [x for x in fig_frame['layout'] if "yaxis" in x]

    for j, cell in enumerate(plots):
        for i, plot_type in enumerate(plots[cell]):
            plot = plots[cell][plot_type]
            if i == 0:
                fig_frame.layout.shapes += plot['layout']['shapes']
                fig_frame['layout'][x_axis[i * len(plots) + j]]['ticktext'] = plot['layout']['xaxis'][
                    'ticktext']
                fig_frame['layout'][x_axis[i * len(plots) + j]]['tickvals'] = plot['layout']['xaxis'][
                    'tickvals']
                fig_frame['layout'][x_axis[i * len(plots) + j]]['tickfont'] = plot['layout']['xaxis'][
                    'tickfont']
                plot = plot['data']
            for sub_trace in plot:
                fig_frame.append_trace(sub_trace, i + 1, j + 1)
    for axis in y_axis[len(plots):-1]:
        fig_frame['layout'][axis]['range'] = [0, 1]
    for axis in x_axis[len(plots):-len(plots)]:
        fig_frame['layout'][axis]['title']['text'] = 'Genomic Window bin 250kb'
    for axis in range(0, len(plots) * 3, len(plots)):
        text = 'Fraction of Intrachromosomal Interactions'
        if axis == 0:
            text = 'Genomic Window bin 250kb'

        fig_frame['layout'][y_axis[axis]]['title']['text'] = text
    plotly.offline.plot(fig_frame, auto_open=True,
                        filename=os.path.join(output_folder,
                                              "chr_" + title_prefix[0].split(" ")[1] + "_task7_plot.html"))


def filter_data_based_on_clusters(data, label, n_cluster=3):
    out_data = []
    length = []
    for i in range(0, n_cluster):
        indexes = np.where(label == i)
        cluster_item = data[indexes].tolist()
        length.append(len(cluster_item))
        out_data = out_data + cluster_item
        print(str(length[-1]) + ' points found for the ' + str(i) + " cluster")

    return out_data, length


interaction_data = {'k562': 'additional/interaction/k562_250.matrixtxt',
                    'mcf7': 'additional/interaction/mcf7_250.matrixtxt',
                    'gm12878': 'additional/interaction/gm12878_250.matrixtxt'}

count_of_clusters = 3
output_folder = 'output/5'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)
setup_logger(output_folder)
outputs = {}
plots = {}
title_prefix = []
for col, cell in enumerate(['gm12878', 'k562', 'mcf7']):
    files, x_axis_labels = get_csv_files('output/4', cell, '250')
    data, normalized = FeaturesManager.process_features(files, 'output/5', cell)
    normalized = np.loadtxt(normalized)
    data = np.loadtxt(data)
    interaction = np.loadtxt(interaction_data[cell])
    sorted_elements, index_key = apply_threshhold_and_sort_data(interaction)
    normalized = normalized[index_key, :]
    data = data[index_key, :]
    label = cluster_datas(normalized, sorted_elements, count_of_clusters)
    np.savetxt(
        os.path.join(output_folder, 'cluster_res_' + cell + '_' + '_chr22.txt'),
        np.append(list(range(0, label.shape[0])), label[np.argsort(index_key)], axis=0).reshape(2,
                                                                                                -1).transpose(),
        fmt='%i')

    clustered_data, length = filter_data_based_on_clusters(data, label)

    plot_box = draw_box_plot(sorted_elements, label, count_of_clusters,
                             True if col is 0 else False)

    plot_scatter = draw_scatter_plot(sorted_elements, label, count_of_clusters,
                                     True if col is 0 else False)

    plot_heat = draw_freq_plot(clustered_data, length, x_axis_labels, 'chromosome22 ' + cell.upper(), col + 1,
                               True if col == 0 else False)
    plots[cell] = {'heat': plot_heat, 'scatter': plot_scatter, 'box': plot_box}
    title_prefix.append('chr22 ' + cell)
draw_plots(plots, title_prefix, output_folder)
print('calculation finished')
