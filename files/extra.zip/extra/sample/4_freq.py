from igap.frequency import Frequency

import os
import numpy as np
from plotly import tools
import plotly.graph_objs as go
import plotly
from igap.common import read_tsv_with_names
import sys
import logging
from datetime import datetime


def setup_logger(log_folder='logs'):
    if not os.path.exists(log_folder):
        os.makedirs(log_folder)
    log_file = os.path.join(log_folder, datetime.now().strftime('log_%H_%M_%S_%f_%d_%m_%Y.log'))
    logging.basicConfig(filename=log_file, level=logging.INFO, format="%(asctime)s: %(message)s")
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))


def create_heat_map_plot(input_file, title="", min_clip=-6, max_clip=6, minor_color=False):
    data, row, column = read_tsv_with_names(input_file)
    data = np.asarray(data, np.float)
    input_data = np.clip(data, min_clip, max_clip)
    if minor_color:
        color_scale = [[0, 'rgb(0,200,0)'], [0.5, 'rgb(255,255,255)'], [1, 'rgb(200,0,0)']]
    else:
        color_scale = [[0, 'rgb(0,0,255)'], [0.5, 'rgb(0,0,0)'], [1, 'rgb(255,255,0)']]

    trace = go.Heatmap(z=input_data, colorscale=color_scale)
    layout = dict(yaxis=dict(range=([len(row), 0])),
                  title=title, width=250,
                  height=250)
    return trace, layout


def draw_plot(plot_arrays, layout_arrays, output_folder="outputs"):
    plots_per_row = int(len(plot_arrays) / 5)
    title = [x['title'] for x in layout_arrays]

    fig_frame = tools.make_subplots(rows=int(len(layout_arrays) / plots_per_row),
                                    cols=plots_per_row,
                                    subplot_titles=title)

    for index, mplot in enumerate(plot_arrays):
        fig_frame.append_trace(mplot, int(index / plots_per_row) + 1, index % plots_per_row + 1)

    y_axis = [x for x in fig_frame['layout'] if "yaxis" in x]
    for axis in y_axis:
        fig_frame['layout'][axis]['range'] = layout_arrays[0]['yaxis']['range']

    for i in fig_frame['layout']['annotations']:
        i['font'] = dict(size=10)
    plotly.offline.plot(fig_frame, auto_open=True,
                        filename=os.path.join(output_folder, "plot.html"))


if not os.path.exists('output/4'):
    os.makedirs('output/4')
setup_logger('output/4')
data_files = Frequency.calculate_frequency('additional/configs/freq.json', 'output/4')

plots = []
layouts = []
for file in data_files:
    title = file.split('/')[-1].split('_')
    plt, lay = create_heat_map_plot(file, title[1] + '_' + title[3] + '_' + title[5])
    plots.append(plt)
    layouts.append(lay)

draw_plot(plots, layouts, 'output/4')
