from igap.common import read_tsv_with_names
import plotly
import numpy as np
from plotly import tools
import os
from igap.preprocess_ntba_data import DataPreprocessor
import sys
import logging
from datetime import datetime


def setup_logger(log_folder='logs'):
    if not os.path.exists(log_folder):
        os.makedirs(log_folder)
    log_file = os.path.join(log_folder, datetime.now().strftime('log_%H_%M_%S_%f_%d_%m_%Y.log'))
    logging.basicConfig(filename=log_file, level=logging.INFO, format="%(asctime)s: %(message)s")
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))


def create_plot(x, y_arrays, chemical_names, show_legends, line_width=4, split_legend_name=False,
                desired_column_name=[]):
    color_array = ['rgb(255, 153, 51)', 'rgb(0, 0, 255)', 'rgb(204, 0, 102)', 'rgb(128, 0, 0)', 'rgb(0, 25, 51)',
                   'rgb(153, 76, 0)', 'rgb(0,255,0)', 'rgb(0,255,255)', 'rgb(255,0,255)']
    skip_color = 0
    data = []
    for i, y in enumerate(y_arrays):
        legend_name = chemical_names[i]
        if split_legend_name:
            legend_name = legend_name.split("_")[0]
            skip_color = 2
            if len(desired_column_name) != 0 and legend_name not in desired_column_name:
                continue

        data.append(
            {'x': x, 'y': y, 'type': 'scatter', 'mode': 'lines',
             'line': dict(width=line_width, color=color_array[min(i + skip_color, len(color_array) - 1)]),
             'showlegend': show_legends,
             'legendgroup': legend_name,
             'name': legend_name})
    return data


def process_file_for_plot(file, show_legends, line_width, split_legend_name):
    sum_all_genes_dba, chemical_list, new_x = read_tsv_with_names(file)
    return create_plot(new_x, sum_all_genes_dba, chemical_list, show_legends, line_width,
                       split_legend_name)


def show_plots(fig_arrays, title_array, out_plot_url="tmp_plot.html"):
    fig_frame = tools.make_subplots(rows=2, cols=len(fig_arrays),
                                    subplot_titles=title_array + [""] * len(title_array))
    for i, figs in enumerate(fig_arrays):
        for j, plt in enumerate(figs):
            for data in plt:
                fig_frame.append_trace(data, j + 1, i + 1)
    y_axis = [x for x in fig_frame['layout'] if "yaxis" in x]
    min_val, max_val = 99, -99
    for data in fig_frame.data:
        t_min = np.min(np.asarray(data.y, float))
        t_max = np.max(np.asarray(data.y, float))
        if t_max > max_val:
            max_val = t_max
        if t_min < min_val:
            min_val = t_min
    max_val = np.ceil(max_val)
    min_val = np.round(min_val - 0.5)
    for index, axis in enumerate(y_axis):
        if index > len(fig_arrays) - 1:
            fig_frame['layout'][axis]['range'] = [-0.001, 0.0015]
        else:
            fig_frame['layout'][axis]['range'] = [min_val, max_val]
    fig_frame['layout'].update(height=800, width=330 * len(fig_arrays))
    plotly.offline.plot(fig_frame, auto_open=True, filename=out_plot_url)


def create_plot_for_ntba(input_files, titles):
    figs_array = []
    for title in titles:
        sum_file_name = input_files[title]['sum']
        mean_file_name = input_files[title]['mean']
        figs = list()
        figs.append(process_file_for_plot(file=sum_file_name, show_legends=False, line_width=4,
                                          split_legend_name=False))
        figs.append(process_file_for_plot(file=mean_file_name, show_legends=False, line_width=4,
                                          split_legend_name=False))
        figs_array.append(figs)
    show_plots(figs_array, titles)


output_folder = 'output/2'
if not os.path.exists(output_folder):
    os.makedirs(output_folder)
setup_logger(output_folder)
# preprocess data

file_output = DataPreprocessor.preprocess_ntba_data('additional/configs/preprocess_ntba.json', output_folder)

# draw plot for previous data

title = ['GENE', 'TSS', 'ENHANCER', 'HOT']
create_plot_for_ntba(file_output, title)
