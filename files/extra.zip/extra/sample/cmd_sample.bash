#!/bin/bash
echo "starting the sample"
igap ntba additional/fa_file/group1.fa additional/pwm additional/configs/parallel_options.txt output/ntba --chemical=none,-10 --shuffling=50 --remove_temp --reuse_output

igap ntba additional/fa_file/group2.fa additional/pwm additional/configs/parallel_options.txt output/ntba --chemical=none,-10 --shuffling=50 --remove_temp --reuse_output
echo "start to merge nTBA data"

igap ntba additional/fa_file/ additional/pwm additional/configs/parallel_options.txt output/ntba --only_merge --input_folder=output/ntba/ --remove_temp --chemical=none,-10
echo "preprocess nTBA data"

igap preprocess_ntba additional/configs/preprocess_ntba.json output/2/
echo "preprocess gm data"

igap preprocess_gm additional/configs/preprocess_gm_data.json output/3/

echo "calculating the freq"

igap calculate_freq additional/configs/freq.json output/4/

echo "feature management"

igap process_feature output/4/ tss output/5

igap process_feature output/4/ hot output/5

echo "sample finished successfully"