import plotly
from plotly import tools
import os
from igap.preprocess_histon_data import HistDataPreprocess
from igap.common import read_tsv_with_names
import sys
import logging
from datetime import datetime


def setup_logger(log_folder='logs'):
    if not os.path.exists(log_folder):
        os.makedirs(log_folder)
    log_file = os.path.join(log_folder, datetime.now().strftime('log_%H_%M_%S_%f_%d_%m_%Y.log'))
    logging.basicConfig(filename=log_file, level=logging.INFO, format="%(asctime)s: %(message)s")
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))


def create_plot(x, y_arrays, chemical_names, show_legends, line_width=4, split_legend_name=False,
                desired_column_name=[]):
    color_array = ['rgb(255, 153, 51)', 'rgb(0, 0, 255)', 'rgb(204, 0, 102)', 'rgb(128, 0, 0)', 'rgb(0, 25, 51)',
                   'rgb(153, 76, 0)', 'rgb(0,255,0)', 'rgb(0,255,255)', 'rgb(255,0,255)']
    skip_color = 0
    data = []
    for i, y in enumerate(y_arrays):
        legend_name = chemical_names[i]
        if split_legend_name:
            legend_name = legend_name.split("_")[0]
            skip_color = 2
            if len(desired_column_name) != 0 and legend_name not in desired_column_name:
                continue

        data.append(
            {'x': x, 'y': y, 'type': 'scatter', 'mode': 'lines',
             'line': dict(width=line_width, color=color_array[min(i + skip_color, len(color_array) - 1)]),
             'showlegend': show_legends,
             'legendgroup': legend_name,
             'name': legend_name})
    return data


def draw_plot(plots, output_folder):
    fig_frame = tools.make_subplots(rows=3, cols=2)

    for i, figs in enumerate(plots):
        for data in figs:
            fig_frame.append_trace(data, i % (3) + 1, int((i / (3)) + 1))

    y_axis = [x for x in fig_frame['layout'] if "yaxis" in x]
    for axis in y_axis:
        fig_frame['layout'][axis]['range'] = [-2, 5]
    fig_frame['layout'].update(height=250 * 3, width=800)
    plotly.offline.plot(fig_frame, auto_open=True,
                        filename=os.path.join(output_folder, "plot.html"))


if not os.path.exists('output/3'):
    os.makedirs('output/3')
setup_logger('output/3')
output = HistDataPreprocess.process_histon_data('additional/configs/preprocess_gm_data.json', 'output/3')
plot = []
for region in ['TSS', 'HOT']:
    for item in list(output[region].keys()):
        sum_all_genes_dba, chemical_list, new_x = read_tsv_with_names(output[region][item]['mean'])
        plot.append(create_plot(new_x, sum_all_genes_dba, chemical_list, False, 2, True))

draw_plot(plot, 'output/3')
