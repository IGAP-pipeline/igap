from igap.bayespi_ntba import BayesPi_nTBA
import os
import sys
import logging
from datetime import datetime


def setup_logger(log_folder='logs'):
    if not os.path.exists(log_folder):
        os.makedirs(log_folder)
    log_file = os.path.join(log_folder, datetime.now().strftime('log_%H_%M_%S_%f_%d_%m_%Y.log'))
    logging.basicConfig(filename=log_file, level=logging.INFO, format="%(asctime)s: %(message)s")
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))


def calculate_ntba(fa_file, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    BayesPi_nTBA.calculate_ntba(chemical_potentials=['none', '-10'],
                                reference_sequences=fa_file,
                                iterations="50", pwm_folder="additional/pwm",
                                output_folder=output_folder,
                                only_collect=False,
                                reuse_output=False,
                                remove_temp=True,
                                parallel_dict='additional/configs/parallel_options.txt')

input_folder='additional/fa_file/'
fa_splited_files = os.listdir(input_folder)

main_output = "output/ntba"
if not os.path.exists(main_output):
    os.makedirs(main_output)
setup_logger(main_output)
group = 1
for file in fa_splited_files:
    if 'fa' in file:
        output_folder = os.path.join(main_output, 'group' + str(group))
        print("start to calculate ntba value for file " + file)
        calculate_ntba(fa_file=os.path.join(input_folder, file), output_folder=output_folder)
        print("Calculating ntba value for file " + file + " has been finished successfully")
        group += 1

# try to merge the datas
BayesPi_nTBA.calculate_ntba(chemical_potentials=['none', '-10'], reference_sequences="",
                            iterations=0, pwm_folder="", output_folder=main_output,
                            only_collect=False,
                            reuse_output=True,
                            remove_temp=True,
                            parallel_dict='',
                            only_merge=True,
                            input_folder=main_output)
