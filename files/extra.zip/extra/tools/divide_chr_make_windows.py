import os
import glob
import logging
import sys
#import common
import random
import argparse
import re
import fnmatch



#this script is used to make a full subset of sequences N from input fasta file
#Then export all of them in one fasta file with a defined sequence_lengh L and a slide window size step M
#it will divide output files into several small file with a predefined file size
#header of fasta files must follow the sample input, for program to work.w
# 6/11/2018 Amna

def read_fasta(fasta_file_name, max_seqs=None):
    sequences = []
    data = ""
    seq_name = None
    with open(fasta_file_name) as ff:
        for line in ff:
            line = line.replace("\n","")
            line = line.replace(" ","")

            if len(line) == 0:
                continue

            if line[0] == '>':
                if data != "":
                    sequences.append((seq_name, data))
                    data = ""
                    if max_seqs is not None and len(sequences) >= max_seqs:
                        break
                seq_name = line[1:]
            else:
                data += line.strip()

    if data != "":
        sequences.append((seq_name, data))
    return sequences

def write_fasta(seqs, fasta_file_name):
  with open(fasta_file_name, "w") as f: #open the file given in arguments in write mode
      for name, seq in seqs:
          f.write(">" + name + "\n" + seq + "\n")


def make_seq4all(sequence_length, windows_size_step, chr_no, input_path,out_path, delimiter, rep_delimiter, header_type):
  global results_folder

  #gathering input
  in_file_name= os.path.basename(input_path)
  in_seq_file= input_path
  # setting up for output
  out_folder=os.path.abspath(out_path)

  results_folder=os.path.join(out_folder,"seq_window/chr"+chr_no)
  if not os.path.exists(results_folder):
    os.makedirs(results_folder)

  #output file name
  out_file_name=in_file_name.replace(".fa","")
  out_file=os.path.join(results_folder,out_file_name)

  out_seq_file= out_file+"_seqLen"+str(sequence_length)+"_winStep"+str(windows_size_step)+"_peaks.fa"

  out_seq_file_name= out_file+"_seqLen"+str(sequence_length)+"_winStep"+str(windows_size_step)+"_peaks.Name"

  print "Reading Input sequence file:", in_seq_file
  print "\nExport sequence file:", out_seq_file
  print "Export element name:", out_seq_file_name

 #read in the fasta file
  seqs=read_fasta(in_seq_file)

 #random shuffle of index
  len_of_seq=range(0,len(seqs))
  selected_seqs=len_of_seq
  set_of_selected_seqs_index=set(selected_seqs)
  print "\nTotal number of sequences:", len(seqs)


#export
  loop=0
  rm_strs=0
  with open(out_seq_file_name,"w") as f_name:
   with open(out_seq_file,"w") as f:
    for name, seq in seqs:
      if loop in set_of_selected_seqs_index:
         f_name.write( name.replace(rep_delimiter[0],rep_delimiter[1]) + "\n")
         start_index=[]
         start_index=[i*windows_size_step for i in range(0,len(seq)-sequence_length)]
         for idx in start_index:
           if idx <= len(seq)-sequence_length:
             tmp_str=seq[idx:idx+sequence_length]
             num_of_n=tmp_str.lower().count("n")
             if (num_of_n/float(sequence_length))<0.5:
                  parts = name.split('|')
                  chordinates = parts[0].split(':')
                  if header_type == 'CHORD':
                      temp  = int(chordinates[1])+(idx+sequence_length/2) #calcualtes real coordinates.
                      f.write(">"+ chordinates[0] + delimiter + str(sequence_length) + delimiter + str(windows_size_step) +
                           delimiter+name.replace(rep_delimiter[0],rep_delimiter[1]) + delimiter+ str(temp) + "\n" + tmp_str +"\n")
                  elif header_type == 'NAME':
                      f.write(">"+ chordinates[0] + delimiter + str(sequence_length) + delimiter + str(windows_size_step) +
                           delimiter+name.replace(rep_delimiter[0],rep_delimiter[1]) + delimiter+ str(idx+sequence_length/2) + "\n" + tmp_str +"\n")
             else:
                rm_strs+=1
      loop+=1
  print "Number of Sequences exported: ",  len(set_of_selected_seqs_index)
  print "Sequences removed with number of N > 50% : ", rm_strs
  return out_seq_file


def divide_files(chr_no, windows_size_step, max_seq_in_file, out_path):

  #This function divides a large file to many small files with predefined maximum file size
  #all import files of test_divide_files.py were subset of that of test_make_seq4all.py, thus removed

  #Gathering input

  in_file_name = os.path.basename(out_path)
  in_seq_file=os.path.join(results_folder,in_file_name)

  #setting up for output
  out_file_name=in_file_name.replace(".fa",".fasta")
  out_seq_file=os.path.join(results_folder,out_file_name)


  print "Divide file: \n", in_seq_file
  print "to small files with maximum size:", str(max_seq_in_file)

  #read in the fasta file
  seqs=read_fasta(in_seq_file)
  loop=0
  batch=[]
  batch_loop=0
  new_seqs=[]
  print "\nTotal size: ", len(seqs)
  total_len=0
  for name, seq in seqs:
      if loop<max_seq_in_file:
         new_seqs.append((name,seq))
      else:
         new_seqs.append((name,seq))
         loop=0
         tmp_str="group_%i.fa" % (batch_loop + 1)
         out_seq_file_name=out_seq_file.replace("peaks.fasta",tmp_str)
         print "Export : " , out_seq_file_name
         write_fasta(new_seqs,out_seq_file_name)
         new_seqs=[]
         batch_loop+=1
      loop+=1
      total_len+=1

      #keep the last few lines if smaller than max_seq_in_file
      if len(new_seqs)>0 and (total_len == len(seqs)):
         tmp_str="group_%i.fa" % (batch_loop + 1)
         out_seq_file_name=out_seq_file.replace("peaks.fasta",tmp_str)
         print "Export : " , out_seq_file_name
         write_fasta(new_seqs,out_seq_file_name)
         batch_loop+=1

  print "Batch size: ", batch_loop
  os.remove(in_seq_file)


if __name__ == "__main__":

  #setting up Input Parameters
  parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter, add_help=False,
                                   description="""This script is used to make a full subset of sequences N from input fasta file
                                                (which can be given chromosomewise, all Chr fasta files must be in hg19 folder with naming convention followed),
                                                It exports all of them in one fasta file with a defined sequence_lengh L and a slide window size step M.
                                                it will divide output files into sevearl small file with a predefined file size.
                                                Command line arguments must be given in the same alphabetic case as given in the help menu. """)
  try:
    required_named = parser.add_argument_group('required arguments')

    optional = parser.add_argument_group('optional arguments')

    required_named.add_argument("--Chr", help="Enter number of Chromosomes", nargs = "+"
                                  , required=True, type=str)

    required_named.add_argument("--In_path", help = "Enter the path for input files", required=True, type=str)

    required_named.add_argument("--Out_path", help = "Enter the path for output files", required=True, type=str)

    required_named.add_argument("--Header", help="""Enter 'NAME' if your input files have fasta headers which contain the chromosme name only (eg: >chr1)
                                  Enter 'CHORD' if your input fasta files have fasta heades with complete choordiantes(eg: >1:12345:67891)."""
                                  ,required=True, type = str)

    optional.add_argument("--Window_step", help="Desired step of window",
                                  default = 4, type=int)

    optional.add_argument("--Sequence_length", help="Desired length of the sequence(window size)",
                                  default = 50, type=int)

    optional.add_argument("--Max_seq", help="Maximum size of sequence in file", type = int, default = 1000000)

    optional.add_argument("--Delimiter", help="Enter Delimiter of your choice. Default is '|'", type = str, default ='|')

    optional.add_argument("--Rep_delimiter", help="""Enter the delimiter in the input file that you want to replace. Takes exactly
                                  2 values. 1st value must be delimiter already present in input. 2nd value must be the
                                  delimiter you want to replace with. 
                                  Default: '|' in the input fasta headers is replaced by '~'.""", type = str, default = ['|','~'], nargs = 2)

    optional.add_argument("-h", "--help", action="help", help="show this help message and exit")

    args = parser.parse_args()
  except IOError as err:
    print >> sys.stderr, "Command line arguments error:", err
    exit(1)

  global spacer
  spacer = "_"


  print "\n*******Dividing the sequence into windows*******\n"

  for chr_no in args.Chr:
    print "\n*****Gathering data for Chr"+chr_no+"*****\n"

    in_files = []

    if chr_no == 'all':
      ending = r"(\w*)\.fa$"
    else:
      ending = r"chr[\.\_\-]"+chr_no+ r"(?!\d)(\w*)\.fa$"
    for root, dirnames, filenames in os.walk(args.In_path):
      for filename in filenames:
          if re.search(ending, filename):
            in_files.append(os.path.join(root, filename))

    for in_file in in_files:
      print"\n*****Moving to next input file.\n"
      peaks_fa =  make_seq4all(args.Sequence_length, args.Window_step, chr_no, in_file, args.Out_path, args.Delimiter, args.Rep_delimiter, args.Header)
      divide_files(chr_no, args.Window_step, args.Max_seq, peaks_fa)
