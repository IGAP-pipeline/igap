#Amna 28nov,3Dec
# for nTBA enhancer and HOT portion
# takes bed file as input to exctract desired sized windows (in bed, makes atag file also) positioned at
# center of given sequences (in bed)
# Can take whole genome bed as input and extract out windows chromosome wise.
# temporary files are not kept till end.
# Edited 17Dec, 8/2/2018
import os, sys
import argparse
import re
import numpy as np
import time

def change_chr(in_file, chr_type):
  #changes the chromosme notation in first colum of bed file.
  #from numeric (1, 23,24,25)to string (chr1,chrX,chrY,chrM) and vice versa

  in_file_name= os.path.basename(in_file)
  delimeter = "\t"

  if chr_type == "NUM":
    out_file= result_folder+"numChr_"+in_file_name
    with open(in_file,"r") as in_f:
      with open(out_file,"w") as out_f:
        for line in in_f:
          in_lines=line.split(delimeter)
          in_lines[0]=re.sub(r'(?i)X',"23",in_lines[0] )
          in_lines[0]=re.sub(r'(?i)Y',"24",in_lines[0] )
          in_lines[0]=re.sub(r'(?i)M',"25",in_lines[0] )
          in_lines[0]=re.sub(r'(?i)chr',"",in_lines[0] ) 
 
          out_line=delimeter.join(in_lines)
          out_f.write(out_line)

  elif chr_type == "STR":
    out_file= in_file.replace("numChr","strChr")
    with open(in_file,"r") as in_f:
      with open(out_file,"w") as out_f:
        for line in in_f:
          in_lines=line.split(delimeter)
          in_lines[0]=re.sub(r'(?i)23',"X",in_lines[0] )
          in_lines[0]=re.sub(r'(?i)24',"Y",in_lines[0] )
          in_lines[0]=re.sub(r'(?i)25',"M",in_lines[0] )
          in_lines[0]= "chr"+ str(in_lines[0])
          out_line=delimeter.join(in_lines)
          out_f.write(out_line)
    os.remove(in_file)
  return out_file

def sort_bed(in_file):
  #sorts bed file on base of Chr and coordiantes
  #input must be bed format
  
    in_file_name= os.path.basename(in_file)
    sort_out_file= result_folder+ "sorted_"+in_file_name
    command= "sort -n -k1 -k2 -k3 " + in_file + " > "+sort_out_file
    os.system(command)
    os.remove(in_file)
    return sort_out_file


def trim_bed(sort_out_file):
  #strips out white spaces at end of each line in bed file

  sort_file_name= os.path.basename(sort_out_file)
  trim_out_file= result_folder+"trim_"+sort_file_name
  
  with open(trim_out_file,"w") as out_f:
   with open(sort_out_file,"r") as in_f:
        for line in in_f:
            line=line.rstrip()
            out_f.write(line+"\n")
   os.remove(sort_out_file)
   return trim_out_file

def data_for_chr(chr, in_file,trim_out_file, file_type):
  #Extracts data for a specific chromosme from given input file.

  print"\n**Fetching bed entries for Chr No: ",chr
  
  if file_type == "ENH":
    search = "^"+chr+"\s"
  elif file_type == "HOT":
    search = "^chr"+chr+"\s" #1st column of HOT region bed file has chr written, not just number
    search = str(search)
  
  simple_name=os.path.basename(in_file)
  chr_out_file= result_folder+"chr"+chr+"_"+simple_name
  with open(chr_out_file,"w") as out_f:
    with open(trim_out_file,"r") as in_f:
        for line in in_f:
            if re.match(search, line, re.IGNORECASE):
              out_f.write(line)
    in_f.close()
  return chr_out_file


def window_bed2bed(in_file, window, file_type): 

#fetches window of given size positioned at center of given sequence

  print"\nWindow size for the elemnts: "+str(window)+"bp"
  delimeter="\t"
  
  # extend upstream and down stream of center of window
  window_size= window #default 1000
  tmp_shift=window_size/2

  out_file=in_file.replace(".bed", "_"+str(window_size)+"bp.bed")
  with open(out_file,"w") as out_f:
    with open(in_file) as in_f:
      for line in in_f:
          if file_type == "ENH":
            line=line.rstrip()
            lines=line.split(delimeter)   
            tmp_col3=lines[3]
            tmp_cols=";"+ "+" + ";" + lines[3] + ";" +lines[4] +"\n"
          elif file_type == "HOT":
            lines=line.split(delimeter)   
            tmp_col3=lines[0].replace("chr","") + ":" + lines[1] + ":" + lines[2] + "|" + lines[3]
            tmp_cols=";"+ lines[5] + ";" + lines[4] + ";" +lines[6] +"\n"  

          tmp_st=int(lines[1])
          tmp_ed=int(lines[2])
          tmp_center=int (np.median(np.array([tmp_st,tmp_ed],int)))
          out_line=(lines[0].replace("chr",""),str(tmp_center-tmp_shift),str(tmp_center+tmp_shift),tmp_col3, tmp_cols)
          out_line=delimeter.join(out_line)
          out_f.write(out_line.replace("_",'|')) #to replace _ in the identifiers of enhnacers only.
  out_f.close()

  if file_type == "ENH":
    print"Windows for Enhancer elements have been calculated with size: "+str(window)+"bp"
  elif file_type == "HOT":
        print"Windows for HOT regions have been calculated with size: "+str(window)+"bp"
  
  return out_file


def remove_dup(in_file):
  #removes duplicate regions from bed file

  prev_line = ["","",""] #to compare only first three columns
  counter = 0

  in_file_name= os.path.basename(in_file)
  out_file = result_folder+"unique_"+in_file_name
  delimeter = "\t"
  with open(out_file, "w") as o_file:
    with open(in_file) as i_file:
      if ".Tag" in in_file: #change delimiter, skip header of input and
        delimeter = ":"      #write header in output if it is a tag file
        o_file.write("ID"+"\t"+"TAG"+"\n")
        i_file.next()
      for line in i_file:
        words =line.split(delimeter)
        if words[1]== prev_line[1] and words[2]== prev_line[2]: #if Chr start and end are same, skip.
            #print line   #remove hash to see which duplicates are removed
            counter += 1
            continue
        o_file.write(line)
        prev_line = words
    print "Duplicate elements found and deleted: ", counter
    os.remove(in_file)
  return out_file

def remove_short(in_file, file_type, min_size):
  #removes coordinates shorter than the given size
  #input is bed format

  print "\nMinimum size of the element: "+str(min_size)+"bp"
  counter = 0
  in_file_name= os.path.basename(in_file)
  out_file = result_folder+"filtered_"+in_file_name
  delimeter = "\t"
  with open(out_file, "w") as o_file:
    with open(in_file) as i_file:
      for line in i_file:
        in_lines=line.split(delimeter)
        if file_type == "ENH":
          tag_col = in_lines[4].split(';')
          if int(tag_col[3]) >= min_size:
            o_file.write(line)
          else:
            counter+=1

        elif file_type == "HOT":
          tag_col = in_lines[3].split('|')
          tag_col2= tag_col[0].split(':') 
          element_length = int(tag_col2[2])-int(tag_col2[1])
          if element_length >= min_size:
            o_file.write(line)
          else:
            counter+=1
  if file_type == "ENH":
    print "Enhancers found less than the minimum size: ", counter
  elif file_type == "HOT":
    print "HOT regions found less than the minimum size: ", counter
  return out_file

def merge_regions(in_file, window, merge_delim, file_type):
  #takes 4 column bed file as input, merges the overlapping coordiantes.
  #recalculates window of merged elements larger than the given window size.
  #uses pybedtools for merging.

  print "\n****Merging the overlapping elements****."

  in_file_name= os.path.basename(in_file)
  out_file = result_folder+"merged_"+in_file_name
  tmp_bed = result_folder+"temp_"+time.strftime("%Y%m%d-%H%M%S")+".bed"

  shift = window/2
  long_merge = 0
  counter = 1
  num_lines = sum(1 for line in open(in_file))

  #merging bed coordinates.
  command = "bedtools merge -i "+ in_file + " -c 4,5 -o count,collapse -delim "+ merge_delim+">"+tmp_bed
  os.system(command)
  print "Re-adjusting the merged regions larger than : ", window

  #assgining new IDs.

  out_file_ID = out_file.replace('.bed','.ID')
  bed_data = np.genfromtxt(fname= tmp_bed, delimiter = '\t', dtype = "str")

  with open(out_file_ID, 'w') as id_file:
    with open(out_file, "w") as o_file:
      with open(tmp_bed, "r") as tmp_file:
        
        for line in tmp_file:
          lines=line.split('\t')
          tmp_st=int(lines[1])
          tmp_ed=int(lines[2])
          length = int(lines[2]) - int(lines[1])
          median_cord = int (np.median(np.array([tmp_st,tmp_ed],int)))

          ID =  file_type+str(counter)+'|'+ str(length)
          info = ';+;'+ID+";"+ str(lines[3]) #assuming enhancers and HOT regions are not strand specific
          out_line_ID = ID +'\t'+ lines[4]
          out_line= ()
          
          if length > window:
            out_line= [lines[0],str(median_cord-shift),str(median_cord+shift),ID, info] #resize window and simplify ID
            long_merge+= 1
          else:
            out_line=[lines[0],lines[1],lines[2],ID, info] #just simplify ID
            
          id_file.write(out_line_ID)
          o_file.write('\t'.join(out_line) +'\n')
          counter+= 1

  print "Number of overlapping elements: ", num_lines- counter
  print "Merged regions longer than defined window size: ", long_merge
  print "Exported ID file for back refrencing to original elements: ", out_file_ID
  os.remove(tmp_bed)
  os.remove(in_file)

  return out_file


def make_tag_file(in_file, tag_delimiter):
  #makes tag file of given input bed file.

  counter = 0
  out_file=in_file.replace(".bed",".Tag")
  delimeter = "\t"

  with open(out_file, "w") as o_file:
    with open(in_file) as i_file:
      for line in i_file:
        in_lines=line.split(delimeter)
        out_line= in_lines[0]+':'+in_lines[1]+':'+in_lines[2]+tag_delimiter+ in_lines[3]
        out_line2=delimeter.join((out_line,in_lines[4]))
        o_file.write(out_line2)
        counter+=1 
  
  print "Total elements exported: ", counter
  print "\nExported Tag file: ", out_file


if __name__ == "__main__":

  parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter, 
                                        add_help=False, description="""This script is used 
                                        for making HOT and enhancer files for nTBA calculation""")
  try:
    required_named = parser.add_argument_group('required arguments')
    optional = parser.add_argument_group('optional arguments')

    required_named.add_argument("--Chr", help="""Enter number of Chromosome can process 
                                          more than one chromosme. Enter 'ALL' for whole genome.""",
                                         default = 'ALL', nargs = "+", required=True, type=str)
    
    required_named.add_argument("--In_path", help = "Enter the path for input files",
                                        required=True,type=str)
    
    required_named.add_argument("--Out_path", help = "Enter the path for output files",
                                        required=True,type=str)
    
    required_named.add_argument("--File_type", help = """Enter ENH for enhancer file OR
                                        HOT for HOT region file.""",
                                        required=True,type=str)    
    
    optional.add_argument("--Window_size", default = 1000, help="Desired step of window, default is 1000bp",
                               type=int)
    
    optional.add_argument("--Keep_temp", default = "N", help="""Type Y if you want to keep sorted 
                                                trimmed version of input file, by default it is deleted""")
    
    optional.add_argument("--Keep_dup", default = "N", help="""Type Y if you want to keep duplicate entries 
                                                in file, by default it is deleted""")
    
    optional.add_argument("--Merge_regions", default = "N", help="""Type Y if you want to merge overlapping regions in 
                                                output, by default overlaps are exported as they are.""")
    
    optional.add_argument("--Min_size", default = 1000, help="""Enter the minum size of elements you want to keep.
                                                Enhancers/HOT less than 1000bp in size are filtered out by default."""
                                                , type = int)
    
    optional.add_argument("--Chr_type", help="""Enter NUM for numeric notation of chromosomes in output (Chr 23,24,25).
                                        Enter STR for string notation of chromosomes in output (Chr X,Y,M). Default is string notation"""
                                        ,default = "NUM", type = str)
    
    optional.add_argument("--Tag_delimiter", help="""Enter the special character you want to use as delimiter between coordinates and
                                      rest of information in first column of tag file. Default separator is '|'."""
                                      , default = '|', type = str)
    
    optional.add_argument("--Merge_delimiter", help="""Enter the special character you want to use as delimiter between merged coordiantes.
                                      Use this if --Merge_regions isused. Default separator is '~'."""
                                      , default = '~', type = str)
    
    args = parser.parse_args()   
  except IOError as err:
    print >> sys.stderr, "Command line arguments error:", err
    exit(1)



  global result_folder
  abs_path = os.path.abspath(args.In_path) 
  result_folder = args.Out_path

  if (args.File_type == 'ENH'):
    print "\n***Generating Files for ENHANCER region****\n"
    result_folder = result_folder + "/enhancer_out/"
    if not os.path.exists(result_folder):
      os.makedirs(result_folder)
  elif (args.File_type == 'HOT'):
    print "\n***Generating Files for HOT region****\n"
    result_folder = result_folder + "/HOT_out/"
    if not os.path.exists(result_folder):
      os.makedirs(result_folder)


    #calling functions.
  change_chr_file = change_chr(args.In_path, chr_type= "NUM")
  sort_out_file= sort_bed(change_chr_file)
  trim_out_file= trim_bed(sort_out_file)
 

  for chr_no in args.Chr:
    if 'ALL' in args.Chr:
      print "Generating whole genome files"
      bed_file= window_bed2bed(trim_out_file, args.Window_size, args.File_type)
      s_bed_file = sort_bed(bed_file)
    else:
      HOT_for_chr= data_for_chr(chr_no,args.In_path,trim_out_file, args.File_type)
      bed_file= window_bed2bed(HOT_for_chr, args.Window_size, args.File_type)
      os.remove(HOT_for_chr)

      s_bed_file = sort_bed(bed_file)
      

    if args.Keep_dup == "Y":
      print "\nRetaining duplicates"
      filtered_bed_file = remove_short(s_bed_file, args.File_type, args.Min_size)
      os.remove(s_bed_file)
      print "\nExporting bed file"
       
    elif args.Keep_dup == "N":
      print "\nRemoving duplicates"
      no_dup_bed_file= remove_dup(s_bed_file)
      filtered_bed_file = remove_short(no_dup_bed_file, args.File_type, args.Min_size)
      os.remove(no_dup_bed_file)
      print "\nExporting bed file"
      
  

  if args.Merge_regions =='Y':
    filtered_bed_file = merge_regions (filtered_bed_file, args.Window_size, args.Merge_delimiter, args.File_type)

  if args.Chr_type =="STR":
    filtered_bed_file =change_chr(filtered_bed_file,args.Chr_type )
  
  print "\nExported bed file: ",filtered_bed_file

  make_tag_file(filtered_bed_file,args.Tag_delimiter)
    
  if args.Keep_temp == "Y":
    print "Exported trimmed and sorted version of input: ",trim_out_file
    pass
  elif args.Keep_temp == "N":
    os.remove(trim_out_file)
  