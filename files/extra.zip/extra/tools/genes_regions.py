#Takes RefFalt file as input and produces windows (user defined) centered on gene center and TSS
#Assigns respective geneID to every computed window.
#Gives output in bed format, and generates Tag file for gene center and TSS 
#Amna Dec2018


import sys , os
import argparse
import pandas as pd
import numpy as np
import time
start_time = time.time()

def read_refFlat (in_path):
  Flat_file = pd.read_table(abs_path, delim_whitespace=True, usecols=[0, 1, 2, 3, 4, 5],
                names=['gene_name', 'rna_name', 'chr', 'strand', 'TSS', 'TES'])
  return Flat_file

def replace_numerical_chr(specie, string):
    # returns ChrNo for Chr name. Specie can be HUM or MUS. string can be X,Y,M
    if specie == 'HUM':
        if string == 'X':
            return '23'
        elif string == 'Y':
            return '24'
        elif string == 'M':
            return '25'
    elif specie == 'MUS':   # mouse
        if string == 'X':
            return '20'
        elif string == 'Y':
            return '21'
        elif string == 'M':
            return '22'


def find_uniq_genes(Flat_file, delete_mir, specie ):
  #Filters and orders data and writes to file

  #Keyword arguments:
  #Flat_file: pandas dataframe
  #specie -- HUM for human, MUS for mouse (default HUM)
  #delete_mir -- delete genes with names starting with mir (default Yes)
  
    Flat_file_copy = Flat_file.copy()

    #Delete records with chromosome name having '_'
    Flat_file_copy = Flat_file_copy[Flat_file_copy.chr.str.contains('_') == False]
    
    #Delete records starting with case insensitive 'mir'
    if delete_mir == "Y":
      Flat_file_copy = Flat_file_copy[Flat_file_copy.gene_name.str.lower().str.startswith('mir') == False]
    elif delete_mir == "N": #keeps records with mir.
      Flat_file_copy = Flat_file_copy[Flat_file_copy.gene_name.str.lower().str.startswith('mir') == True]

         
    #removes duplicates
    Flat_file_copy = Flat_file_copy.drop_duplicates(subset=['chr', 'strand', 'TSS', 'TES'])

    chrs = Flat_file_copy.chr.str[3:]

    X_mask = chrs == 'X'
    chrs.loc[X_mask] = replace_numerical_chr(specie, 'X')

    Y_mask = chrs == 'Y'
    chrs.loc[Y_mask] = replace_numerical_chr(specie, 'Y')

    M_mask = chrs == 'M'
    chrs.loc[M_mask] = replace_numerical_chr(specie, 'M')

    Flat_file_copy['order_by_chr'] = chrs
    Flat_file_copy.chr = pd.to_numeric(Flat_file_copy.order_by_chr)
    
    #sorts first by chr, then TSS, then rna_name
    Flat_file_copy = Flat_file_copy.sort_values(by=['chr', 'TSS', 'rna_name'], ascending=True)
    

    print "Total number of unique genes: ",len(Flat_file_copy.index)

    #enusres order of the coloumn
    Flat_file_copy = Flat_file_copy[['rna_name', 'chr', 'strand', 'TSS', 'TES', 'gene_name']]
    
    outfile = result_folder+"unique_sorted_"+in_file_name

    np.savetxt(outfile, Flat_file_copy.values, fmt='%s', delimiter='\t')
    return outfile

def get_windows(unique_gene_file, window_size, min_size):
  unique_genes = pd.read_table(unique_gene_file, delim_whitespace=True, usecols=[0, 1, 2, 3, 4, 5],
                names=['rna_name', 'chr', 'strand', 'TSS', 'TES','gene_name'])
  gene_file_tag= "_gene_center_"+str(window_size)+"bpwindow.bed"
  gene_center_out_file= unique_gene_file.replace('.txt',gene_file_tag)
  TSS_file_tag= "_TSS_"+str(window_size)+"bpwindow.bed"
  TSS_out_file= unique_gene_file.replace('.txt',TSS_file_tag)
  
  tag= "|Up;500;Down;500"                
  unique_genes["gene_info"]= ';'+ unique_genes['strand'].astype(str)+';'+unique_genes['rna_name'].astype(str)+';'+unique_genes['gene_name'].astype(str)+ tag

  # for Gene Center

  min_filtered_gene = unique_genes.copy()
  indexNames = min_filtered_gene[min_filtered_gene['TES']-min_filtered_gene['TSS'] < min_size].index
  print "Minimum size for gene: "+str(min_size)+"bp"
  print "Genes found less than the defined minimum size: ", indexNames.size
  
  min_filtered_gene.drop(indexNames, inplace = True)
  print "Genes found above the minimum size: ", len(min_filtered_gene.index)

  min_filtered_gene["gene_mid"] = min_filtered_gene[["TSS","TES"]].median(axis= 1).astype(int) #medians of values of these                                                                                    #2 columns with decimals removed
  up_down= window_size/2
  min_filtered_gene["wind_start_pos"]  = min_filtered_gene["gene_mid"] - up_down
  min_filtered_gene["wind_end_pos"] = min_filtered_gene["gene_mid"] + up_down
 
  gene_center_wind = min_filtered_gene[['chr', 'wind_start_pos', 'wind_end_pos','gene_info']] #order of data column in ouput
  gene_center_wind = gene_center_wind.sort_values(by=['chr', 'wind_start_pos', 'wind_end_pos'], ascending=True)#sorting before writing
  
  np.savetxt(gene_center_out_file,gene_center_wind.values, fmt='%s', delimiter= '\t' )
  print"\nWindows for gene center have been calculated with size: ",window_size
  print gene_center_out_file
  
  #for TSS
  
  unique_genes['TSS_start'] = np.nan
  unique_genes['TSS_end'] = np.nan

  unique_genes.loc[unique_genes['strand']== '+', 'TSS_start']= unique_genes['TSS']-up_down
  unique_genes.loc[unique_genes['strand']== '-', 'TSS_end']= unique_genes['TES']+up_down

  unique_genes.loc[unique_genes['strand']== '+', 'TSS_end']= unique_genes['TSS']+up_down
  unique_genes.loc[unique_genes['strand']== '-', 'TSS_start']= unique_genes['TES']-up_down

  unique_genes[['TSS_start','TSS_end']] = unique_genes[['TSS_start','TSS_end']].astype(int)

  TSS_wind= unique_genes[['chr','TSS_start', 'TSS_end','gene_info']] #order of data column in output
  TSS_wind = TSS_wind.sort_values(by=['chr', 'TSS_start', 'TSS_end'], ascending=True) #sorting before writng.

  np.savetxt(TSS_out_file,TSS_wind.values, fmt='%s', delimiter= '\t')
  print"Windows for TSS have been calculated with size: ",window_size

  return gene_center_out_file , TSS_out_file


def get_gene_id(infile, gene_info_file, rem_dup, chr_type, tag_delimiter):
  #Assigns geneID to the every record in the infile ( file with windows centered at TSS or center of gene )
  #geneID is taken from gene_info_file
  #variables having gene_center in the name are not only for gene center,
  # same code works for TSS too.

  df_gene_center = pd.read_table(infile, delim_whitespace=True, usecols=[0, 1, 2, 3],
                names=['chr', 'wind_start_pos', 'wind_end_pos','gene_info'])
  df_gene_info = pd.read_table(gene_info_file, delim_whitespace=True, usecols=[ 1, 2, 3],
                names=['gene_ID','gene_symbol', 'gene_aliases'])
  
  #setting output files
  outfile_name= os.path.basename(infile)
  outfile = result_folder+outfile_name

  df_gene_info.dropna(inplace= True)
 
  df_gene_center['gene_name'] = np.nan
  df_gene_center['gene_name2'] = np.nan 
  df_gene_center['gene_name_ID']= np.nan
  df_gene_center['gene_aliases2']= np.nan

  #extract gene name. surround it with | to make sure exact match
  df_gene_center['gene_name'] = df_gene_center.gene_info.str.extract(r'\d\;(.*)\|') #extract anything surrounded by a number; and |
  df_gene_center['gene_name2'] = '|'+df_gene_center['gene_name'].astype(str)+'|'

  df_gene_info['gene_aliases2'] = '|'+df_gene_info['gene_aliases'].astype(str)+'|'
  
  for gc_index, gc_value in enumerate(df_gene_center['gene_name']):
    for gi_index, gi_value in enumerate(df_gene_info['gene_symbol']):
      if str(gc_value) == str(gi_value):
        df_gene_center.ix[gc_index,"gene_name_ID"]= df_gene_info.ix[gi_index,"gene_ID"] + "|"+ df_gene_center.loc[gc_index,'gene_name']
        break  

  #search for gene names in the gene symbol and gene aliases, if found, assign the respective geneID
  for gc_index, gc_value in enumerate(df_gene_center['gene_name2']):
    if df_gene_center.ix[gc_index,"gene_name_ID"] == np.nan:
      for gi_index, gi_value in enumerate(df_gene_info['gene_aliases2']):
        if str(gc_value) in str(gi_value):
          df_gene_center.ix[gc_index,"gene_name_ID"]= df_gene_info.ix[gi_index,"gene_ID"] + "|"+ df_gene_center.loc[gc_index,'gene_name']
          break 

  #ensure order of columns in data
  df_gene_center_tmp= df_gene_center[['chr','wind_start_pos','wind_end_pos','gene_name_ID','gene_info']]

  #drop entries with no geneID assigend to gene name (means non coding RNA etc)
  df_gene_center_tmp[df_gene_center_tmp.gene_name_ID.str.lower().str.startswith('nan|') == False]

  total_element = df_gene_center_tmp.shape[0]
  print "Total number of elements: ", total_element


  if rem_dup =='C':
    print "Removing duplicate entries for same corrdiantes"
    df_gene_center_tmp = df_gene_center_tmp.drop_duplicates(subset=['chr','wind_start_pos','wind_end_pos'])
    print "Duplicates found and removed: ",  total_element- df_gene_center_tmp.shape[0]
    print "Number of unique elements exported: ", df_gene_center_tmp.shape[0]
    outfile= outfile.replace('.bed','_C_geneID.bed')

  elif rem_dup =='G': 
    print "Removing duplicate entries for same gene"
    df_gene_center_tmp = df_gene_center_tmp.drop_duplicates(subset=['gene_name_ID'])
    print "Duplicates found and removed: ", total_element - df_gene_center_tmp.shape[0]
    print "Number of unique elements exported: ", df_gene_center_tmp.shape[0]
    outfile= outfile.replace('.bed','_G_geneID.bed')

  elif rem_dup =='GC':  #Default: drop multiple entries for a gene, if the coordiantes are same too
    print "Removing duplicate entries for genes with similar coordinates"
    df_gene_center_tmp = df_gene_center_tmp.drop_duplicates(subset=['chr','wind_start_pos','wind_end_pos','gene_name_ID'])
    print "Duplicates found and removed: ", total_element - df_gene_center_tmp.shape[0]
    print "Number of unique elements exported: ", df_gene_center_tmp.shape[0]
    outfile= outfile.replace('.bed','_GC_geneID.bed')

  elif rem_dup == 'N': #keep all sorts of duplicates.
    print "Generating files with duplicates"
    print "Number of elements exported: ", df_gene_center_tmp.shape[0]
    outfile= outfile.replace('.bed','_N_geneID.bed')

   
  if chr_type == "STR":
    df_gene_center_tmp["chr"].replace([23,24,25], ['X','Y','M'], inplace = True)
    df_gene_center_tmp["chr"]= "chr"+df_gene_center_tmp["chr"].astype(str)
    pd.options.mode.chained_assignment = None


  #writing bed file 
  np.savetxt(outfile,df_gene_center_tmp.values, fmt='%s', delimiter= '\t' )
  print"\nExported bed file :", outfile

  #arrangements for .Tag file
  df_gene_center_tmp["Tagfile_ID"] = df_gene_center_tmp['chr'].astype(str)+':'+df_gene_center_tmp['wind_start_pos'].astype(str)+':'+df_gene_center_tmp['wind_end_pos'].astype(str)+str(tag_delimiter)+df_gene_center_tmp['gene_name_ID'].astype(str)
  df_gene_center_tmp2= df_gene_center_tmp[['Tagfile_ID','gene_info']]

  #writing tag file
  outfile_tag= outfile.replace('.bed','.Tag')
  np.savetxt(outfile_tag,df_gene_center_tmp2.values, fmt='%s', delimiter= '\t' )
  print"Exported Tag file :", outfile_tag



if __name__ == "__main__":
  parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter, 
                                        add_help=False, description="""This script is used 
                                        for making gene files for nTBA calculation""")
  try:
    required_named = parser.add_argument_group('required arguments')
    
    optional = parser.add_argument_group('optional arguments')
    
    required_named.add_argument("--In_path", help = "Enter the path for input file",
                                        required=True,type=str)
    
    required_named.add_argument("--Out_path", help = "Enter the path for output files",
                                        required=True,type=str)
    
    required_named.add_argument("--Gene_info", help = "Enter the path for Gene Information file",
                                        required=True,type=str)
    
    optional.add_argument("--Del_mir", help = '''Enter Y if you want to remove mir, N to keep mir.
                                        default is Y''', type= str, default = "Y")
    
    optional.add_argument("--Window_size", default = 1000, help="Desired step of window, default is 1000bp",
                                        type=int)
    
    optional.add_argument("--Specie", help = "Enter HUM for Human or MUS for Mouse. Default is Human",
                                        default = "HUM",type=str)
    
    optional.add_argument("--Keep_temp", help = "Type Y if you want to keep intermediate files( Files are delted at default setting)",
                                        default = "N",type=str)
    
    optional.add_argument("--Rem_dup", help = """Type G if you want to remove multiple entries for same gene(Irrespective of the coordinates).
                                        Type C if you want to remove multiple entries for same coordinates (Irrespective of gene).
                                        Type GC if you want to remove multiple entries with same gene and coordinates.
                                        Type N if you want too keep all sorts of duplicates. """,  
                                        default = "GC",type=str)
    
    optional.add_argument("--Min_size", help="""Enter the minum size of Genes you want to keep.
                                        Genes less than 1000bp in size are filtered out by default."""
                                      , default = 1000, type = int)
    
    optional.add_argument("--Chr_type", help="""Enter NUM for numeric notation of chromosomes in output (Chr 23,24,25).
                                        Enter STR for string notation of chromosomes in output (Chr X,Y,M). Default is string notation"""
                                        ,default = "NUM", type = str)
    
    optional.add_argument("--Tag_delimiter", help="""Enter the special character you want to use as delimiter between coordinates and
                                      rest of information in first column of tag file. Default separator is '|'."""
                                      , default = '|', type = str)
    args = parser.parse_args()   
  
  except IOError as err:
  
    print >> sys.stderr, "Command line arguments error:", err
    exit(1)

  #setting up input and output paths.
  global result_folder
  abs_path = os.path.abspath(args.In_path) 
  in_file_name= os.path.basename(args.In_path)
  result_folder = args.Out_path
  result_folder = result_folder + "/gene_out/"
  
  if not os.path.exists(result_folder):
    os.makedirs(result_folder)

  # read the input (refFlat file)
  Flat_file = read_refFlat(abs_path)  
  print "\nCollecting unique genes from refFalt file: ",in_file_name
  unique_gene_file = find_uniq_genes(Flat_file, args.Del_mir,args.Specie)
  gene_center_file , TSS_file = get_windows(unique_gene_file, args.Window_size, args.Min_size)
  os.remove(unique_gene_file)  

  print "\n***Generating Files for GENE CENTER****"
  get_gene_id(gene_center_file, args.Gene_info, args.Rem_dup, args.Chr_type, args.Tag_delimiter)
  
  if args.Keep_temp =='N':
    os.remove(gene_center_file)
  elif args.Keep_temp == 'Y':
     print"\nExporting Gene Center file (keeping temporary file) :", gene_center_file


  print "\n***Generating Files for TSS****"
  get_gene_id(TSS_file,args.Gene_info, args.Rem_dup, args.Chr_type, args.Tag_delimiter)

  if args.Keep_temp =='N':
    os.remove(TSS_file)
  elif args.Keep_temp == 'Y':
     print"\nExporting TSS file (keeping temporary file) :", TSS_file

  print "Time taken(in seconds): ", (time.time()-start_time)