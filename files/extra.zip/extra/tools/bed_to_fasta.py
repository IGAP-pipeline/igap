# Fetches fasta sequence for the given bed coordinates
# can fetch fasta sequence for fixed number fo random bed coordiantes.



import argparse, os
from Bio import SeqIO
from Bio.SeqIO import FastaIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from collections import defaultdict
import glob
import shutil
import time
import random

start_time = time.time()


def make_whole_genome_fasta(input_folder):
	#combines all the fasta files to one whole genome fasta file.
	
	whole_genome= result_folder+"whole_genome"+str(time.ctime())+".fa"
	input_files= input_folder+"/*.fa"
	print "Combining input fasta sequences"
	with open(whole_genome, 'wb') as outfile:
		for filename in glob.glob(input_files):
			if filename == whole_genome:
					# don't want to copy the output into the output
				continue
			with open(filename, 'rb') as readfile:
				shutil.copyfileobj(readfile, outfile)
	
	return whole_genome

def random_bed(input_bed, random_count, export_random, st, delimiter):
	#Extracts given number of random bed coordinates from bed file.

	input_bed_name= os.path.basename(input_bed)
	random_chosen_file = result_folder+"rand"+str(random_count)+"_"+input_bed_name
	f_st = "_"+str(st)+".bed"
	random_chosen_file = random_chosen_file.replace('.bed',f_st)
	positions = defaultdict(list)
	random_chosen = []
	#count_bed = 0

	with open(input_bed) as f:
		count_bed = len(open(input_bed).readlines(  ))
		print "\n***************************"
		if random_count > 0:
			lines = random.sample(f.readlines(),random_count)
			random_chosen = lines
		elif random_count == 0:
			lines = f.readlines()
			random_count = count_bed
	if st == 1:
		print "Total number of bed records given: ", count_bed
		print "Number of bed records chosen: ", random_count
		print "***************************\n"
	
	for line in lines:
		in_line = line.split()
		fasta_id = in_line[0]+':'+ in_line[1]+':'+ in_line[2] +delimiter+ in_line[3]
		in_line[0] = in_line[0].replace('23','X').replace('24','Y').replace('25','MT').replace('chr','')
		positions[in_line[0]].append((int(in_line[1]), int(in_line[2]), in_line[3], in_line[4], fasta_id))
	
	if export_random =="Y":
		with open(random_chosen_file, 'w') as f:
			for line in random_chosen:
				f.write(line)
		print "Exporting randomly chosen bed coordinates file : ", random_chosen_file

	elif export_random =="N":
		pass

	return positions


def get_fasta(WG_fasta, positions, in_file_bed, threshold, random_count,st):
	#fetches fasta sequnces for the given bed coordiantes.
	#removes repeat sequenes above given threshold

	in_file_bed_name= os.path.basename(in_file_bed)
	out_file_bed = result_folder+"fastaSeq_rand"+str(random_count)+"_"+in_file_bed_name
	st = "_set"+str(st)+".fa"
	out_file_bed = out_file_bed.replace('.bed',st)
	out_file_tag = out_file_bed.replace('.fa','.Tag')

	count_repeat= 0
	
	#parse fasta file and turn into dictionary
	records = SeqIO.to_dict(SeqIO.parse(open(WG_fasta), 'fasta'))

	# search for short sequences
	short_seq_records = []
	with open(out_file_tag, 'w') as f_tag:
		for chr_name in positions:
				for (start, end, element_info1, element_info2, fasta_id) in positions[chr_name]:
					
					if chr_name in records:
						chr_seq_record = records[chr_name]
						chr_seq = chr_seq_record.seq
						alphabet = chr_seq.alphabet
						short_seq = str(chr_seq)[start-1:end]
						N_count = short_seq.lower().count('n')
						total_count= len(short_seq)
						repeat_percent = N_count*100/total_count
						
						if repeat_percent >= threshold:
							print "Record removed for repeats above threshold", fasta_id
							count_repeat+=1
						else:
							short_seq_record = SeqRecord(Seq(short_seq, alphabet), id= fasta_id, description='')
							short_seq_records.append(short_seq_record)
							tag_id = fasta_id+"\t"+element_info2+"\n" # working here, its wrong
							f_tag.write(tag_id)
					else:
						print "Chrosome"+chr_name+" not found in input fasta"
				
	print "\nNumber of sequences with repeats(>"+str(threshold)+"%) removed: ", count_repeat
	print "Fasta records exported: ", len(short_seq_records)
	print "\nExporting Tag file : ",out_file_tag

	# write to fasta file
	with open(out_file_bed, 'w') as f:
			fasta_out = FastaIO.FastaWriter(f, wrap = None)
			fasta_out.write_file(short_seq_records)
			print "Exporting Fasta file : ", out_file_bed


if __name__ == "__main__":
	parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter, 
																				add_help=False, description="""This script is used 
																				for extracting fasta sequence from fasta files,   
																				based on the bed coordinates given in input bedfile.""")
	try:
		required_named = parser.add_argument_group('required arguments')
		
		optional = parser.add_argument_group('optional arguments')
		
		required_named.add_argument("--In_path_fasta", help = "Enter the path for directory containg input fasta files"
																				, required=True,type=str)
		
		required_named.add_argument("--In_path_bed", help = "Enter the path for input bed file"
																				, required=True,type=str)
		
		required_named.add_argument("--Out_path", help = "Enter the path for output files"
																				, required=True,type=str)
		
		optional.add_argument("--Rep_threshold", help="""Fasta sequences having repeat sequence more
																				exceedign this threshold will be deleted. Default: Records
																				composed of more than 50\% of repeat sequences are deleted."""
																				, default = 50, type = int)
		
		optional.add_argument("--Export_sets", help = """Type number of sets of output you want. Default is 1."""
																				,default= 1, type=int)
		
		optional.add_argument("--Keep_temp", help = '''Type Y if you want to keep intermediate files
																					( Files are deleted at default setting)'''
																				, default = "N",type=str)
		
		optional.add_argument("--Select_random", help = """Type number of bed records you want to be chosen
																				randomly. Default: All bed coordinates are used (0 random sequences are chosen)."""
																				,default= 0, type=int)
		
		optional.add_argument("--Export_random", help = """Type Y if you want the bed coordinates which have been 
																					chosen randomly, in a separate file. This option must be chosen if 
																					--Select_random has been given a value >0."""
																				,default= 'N', type=str)
		
		optional.add_argument("--Delimiter", help = """Type delimiter (for ID) of your choice. default is '|'."""
																				,default= '|', type=str)
		
		required_named.add_argument("--File_type", help = """What is your bed file about ? Enter the name of
																				genomic element your bed file has coordinates for (e.g. Enhacner)""",
																				required=True,type=str)
		args = parser.parse_args()   
	
	except IOError as err:
		print >> sys.stderr, "Command line arguments error:", err
		exit(1)

	global result_folder
	abs_path_bed = os.path.abspath(args.In_path_bed) 
	abs_path_fasta = os.path.abspath(args.In_path_fasta) 

	result_folder = args.Out_path

	print "\n***Fetching FASTA sequences for "+args.File_type+" region****\n"
	result_folder = result_folder + "/"+args.File_type+"_fasta/"
	
	if not os.path.exists(result_folder):
		os.makedirs(result_folder)

	WG_fasta = make_whole_genome_fasta(abs_path_fasta)

	for st in range(1,args.Export_sets+1):
		dict_bed= random_bed(abs_path_bed, args.Select_random, args.Export_random, st, args.Delimiter)
		get_fasta(WG_fasta, dict_bed, abs_path_bed, args.Rep_threshold, args.Select_random, st )
	
	if args.Keep_temp == 'N':
		os.remove(WG_fasta)
	elif args.Keep_temp =='Y':
		pass
	
	print "Time taken(in seconds): ", (time.time()-start_time)